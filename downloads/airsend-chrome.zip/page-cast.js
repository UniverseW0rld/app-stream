// Corre en el mundo de la página (no en el de la extensión): solo aquí se puede usar el SDK de Cast.
// Habla con content.js mediante eventos con texto JSON.
(() => {
  if (window.__airsendPage) return;
  window.__airsendPage = true;

  const SDK = 'https://www.gstatic.com/cv/js/sender/v1/cast_sender.js?loadCastFramework=1';
  // Si el reproductor de la web ya trae Cast, se usa su configuración y no se toca
  const pageHadSdk = Boolean(window.cast?.framework);
  let loading = false;
  let configured = pageHadSdk;
  const isReady = () => Boolean(window.cast?.framework?.CastContext && window.chrome?.cast?.media);

  const emit = (state, extra = {}) =>
    document.dispatchEvent(new CustomEvent('airsend:status', { detail: JSON.stringify({ state, ...extra }) }));

  function context() {
    const ctx = cast.framework.CastContext.getInstance();
    if (!configured) {
      try {
        ctx.setOptions({ receiverApplicationId: chrome.cast.media.DEFAULT_MEDIA_RECEIVER_APP_ID, autoJoinPolicy: chrome.cast.AutoJoinPolicy.ORIGIN_SCOPED });
      } catch {}
      configured = true;
    }
    return ctx;
  }

  function prepare() {
    if (isReady() || loading) return;
    loading = true;
    const prev = window.__onGCastApiAvailable;
    window.__onGCastApiAvailable = (ok) => {
      if (typeof prev === 'function') prev(ok);
      if (ok && isReady()) context();
    };
    const s = document.createElement('script');
    s.src = SDK;
    s.onerror = () => { loading = false; };
    (document.head || document.documentElement).append(s);
  }

  async function requestSession() {
    if (!isReady()) return emit('nosdk');
    const ctx = context();
    try {
      if (!ctx.getCurrentSession()) await ctx.requestSession();
      emit('session', { device: ctx.getCurrentSession().getCastDevice().friendlyName });
    } catch (e) {
      emit(e === 'cancel' ? 'cancel' : 'error', { message: String(e) });
    }
  }

  async function load(data) {
    const session = cast.framework.CastContext.getInstance().getCurrentSession();
    if (!session) return emit('error', { message: 'sin sesión' });
    const info = new chrome.cast.media.MediaInfo(data.url, data.type);
    info.streamType = chrome.cast.media.StreamType.BUFFERED;
    info.metadata = new chrome.cast.media.GenericMediaMetadata();
    info.metadata.title = data.title || 'AirSend';
    if (data.poster) info.metadata.images = [new chrome.cast.Image(data.poster)];
    const req = new chrome.cast.media.LoadRequest(info);
    req.currentTime = data.time || 0;
    try {
      await session.loadMedia(req);
      emit('playing', { device: session.getCastDevice().friendlyName, url: data.url });
    } catch (code) {
      emit('loadfail', { message: String(code) });
    }
  }

  document.addEventListener('airsend:prepare', prepare);
  // Se llama dentro del clic del usuario: Chrome solo abre la lista de dispositivos con un gesto
  document.addEventListener('airsend:session', requestSession);
  document.addEventListener('airsend:load', (e) => load(JSON.parse(e.detail)));
})();
