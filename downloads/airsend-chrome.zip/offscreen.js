// Documento oculto: captura la pestaña y la manda por WebRTC a un receptor My Multimedia o a
// un Chromecast. Es el método de la extensión AirRecied Cast. Vive aquí porque el service
// worker no puede usar getUserMedia ni RTCPeerConnection.

let current = null; // { pc, stream, ch, id, monitor }

chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (msg?.target !== 'offscreen') return false;
  if (msg.type === 'start') {
    start(msg).catch((e) => finish(e.message || String(e)));
    reply({ ok: true });
  } else if (msg.type === 'stop') {
    finish(null).then(() => reply({ ok: true }));
    return true;
  }
  return false;
});

function report(phase, error) {
  return chrome.runtime.sendMessage({ type: 'airsend:mirror-state', phase, error: error || null }).catch(() => {});
}

async function api(host, token, path, { method = 'GET', body, timeoutMs = 8000 } = {}) {
  const headers = token ? { 'X-Auth-Token': token } : {};
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  let res;
  try {
    res = await fetch(`http://${host}${path}`, {
      method, headers, cache: 'no-store',
      body: body === undefined ? undefined : JSON.stringify(body),
      signal: AbortSignal.timeout(timeoutMs)
    });
  } catch {
    throw Object.assign(new Error('No se encuentra el receptor en la Wi‑Fi.'), { status: 0 });
  }
  if (res.status === 204) return {};
  const data = await res.json().catch(() => ({}));
  if (!res.ok && res.status !== 202) throw Object.assign(new Error(data.error || `Error ${res.status}`), { status: res.status });
  return data || {};
}

// Dos buzones para intercambiar la oferta y la respuesta WebRTC:
//   mm   → la API del receptor My Multimedia (/api/mirror/...)
//   cast → el programa del PC (/mirror/...), que abre la página receptora en el Chromecast
const PC = '127.0.0.1:8787';
function channel({ via, host, token, deviceId }) {
  if (via === 'cast') {
    return {
      async offer(sdp) {
        const out = await api(PC, '', '/mirror/start', { method: 'POST', body: { id: deviceId, sdp }, timeoutMs: 30000 });
        if (out.error) throw new Error(out.error);
        return out.sid;
      },
      answer: async (sid) => (await api(PC, '', `/mirror/answer?s=${encodeURIComponent(sid)}`)).sdp,
      alive: async (sid) => (await api(PC, '', `/mirror/status?s=${encodeURIComponent(sid)}`, { timeoutMs: 4000 })).alive !== false,
      stop: (sid) => api(PC, '', `/mirror/stop?s=${encodeURIComponent(sid)}`, { method: 'POST', timeoutMs: 3000 })
    };
  }
  return {
    offer: async (sdp, title) => (await api(host, token, '/api/mirror/offer', { method: 'POST', body: { sdp, title } })).id,
    answer: async (id) => (await api(host, token, `/api/mirror/answer?id=${encodeURIComponent(id)}`)).sdp,
    alive: async () => (await api(host, token, '/api/status', { timeoutMs: 4000 })).mirroring !== false,
    stop: (id) => api(host, token, `/api/mirror/stop?id=${encodeURIComponent(id)}`, { method: 'POST', timeoutMs: 3000 })
  };
}

async function start(opts) {
  const { streamId, title } = opts;
  const ch = channel(opts);
  await finish(null, { silent: true });

  const stream = await navigator.mediaDevices.getUserMedia({
    audio: { mandatory: { chromeMediaSource: 'tab', chromeMediaSourceId: streamId } },
    video: { mandatory: { chromeMediaSource: 'tab', chromeMediaSourceId: streamId, maxWidth: 1920, maxHeight: 1080, maxFrameRate: 30 } }
  });

  // El sonido de la pestaña pasa a oírse solo en el receptor, como con el «Enviar pestaña» de Chrome
  const pc = new RTCPeerConnection({ iceServers: [] }); // Solo red local
  current = { pc, stream, ch, id: null, monitor: null };

  for (const track of stream.getTracks()) {
    if (track.kind === 'video') track.contentHint = 'motion';
    const tr = pc.addTransceiver(track, { direction: 'sendonly', streams: [stream] });
    if (track.kind === 'video') preferH264(tr);
    track.addEventListener('ended', () => finish(null)); // pestaña cerrada o captura detenida
  }

  pc.addEventListener('connectionstatechange', () => {
    const state = pc.connectionState;
    if (state === 'connected') { tuneBitrate(pc); report('live'); }
    else if (state === 'failed') finish('Se perdió la conexión con el receptor.');
    else if (state === 'disconnected') {
      setTimeout(() => {
        if (current?.pc === pc && pc.connectionState === 'disconnected') finish('El receptor dejó de responder.');
      }, 8000);
    }
  });

  await pc.setLocalDescription(await pc.createOffer());
  await waitForIce(pc, 3000);

  const id = await ch.offer(pc.localDescription.sdp, title || '');
  if (current?.pc !== pc) { ch.stop(id).catch(() => {}); return; } // se canceló mientras tanto
  current.id = id;

  const answer = await waitForAnswer(ch, id, pc);
  if (!answer) return;
  await pc.setRemoteDescription({ type: 'answer', sdp: answer });

  // Si en el receptor cierran el visor (o la tele cambia de app), se para también aquí
  current.monitor = setInterval(async () => {
    try {
      if (!await ch.alive(id)) finish(null);
    } catch (e) {
      if (e.status === 401) finish('El receptor pidió un código nuevo.');
    }
  }, 4000);
}

async function waitForAnswer(ch, id, pc) {
  const deadline = Date.now() + 40000;
  while (Date.now() < deadline) {
    if (current?.pc !== pc) return null;
    const sdp = await ch.answer(id);
    if (sdp) return sdp;
    await new Promise((r) => setTimeout(r, 300));
  }
  throw new Error('El receptor no respondió. Comprueba que está encendido y vuelve a intentarlo.');
}

function waitForIce(pc, timeoutMs) {
  if (pc.iceGatheringState === 'complete') return Promise.resolve();
  return new Promise((resolve) => {
    const timer = setTimeout(resolve, timeoutMs);
    pc.addEventListener('icegatheringstatechange', () => {
      if (pc.iceGatheringState === 'complete') { clearTimeout(timer); resolve(); }
    });
  });
}

// H.264 se decodifica por hardware en casi todos los receptores: menos calor y menos tirones
function preferH264(transceiver) {
  const caps = RTCRtpSender.getCapabilities?.('video');
  if (!caps || !transceiver.setCodecPreferences) return;
  const rank = (c) => (c.mimeType === 'video/H264' ? 0 : c.mimeType === 'video/VP8' ? 1 : 2);
  try { transceiver.setCodecPreferences([...caps.codecs].sort((a, b) => rank(a) - rank(b))); } catch {}
}

async function tuneBitrate(pc) {
  for (const sender of pc.getSenders()) {
    if (sender.track?.kind !== 'video') continue;
    const params = sender.getParameters();
    if (!params.encodings?.length) params.encodings = [{}];
    params.encodings[0].maxBitrate = 8_000_000;
    params.encodings[0].maxFramerate = 30;
    try { await sender.setParameters(params); } catch {}
  }
}

async function finish(error, { silent = false } = {}) {
  const s = current;
  current = null;
  if (s) {
    clearInterval(s.monitor);
    s.stream.getTracks().forEach((t) => t.stop());
    s.pc.close();
    // Se avisa al receptor antes de informar: al informar, el service worker cierra este documento
    if (s.id) await s.ch.stop(s.id).catch(() => {});
  }
  if (!silent && (s || error)) await report(error ? 'error' : 'idle', error);
}
