// Página que se conecta al Chromecast (las extensiones no pueden cargar el SDK de Cast).
// Para probar en local: npx vite → http://localhost:5173/cast.html
const SENDER_URL = 'https://alvarosiles.github.io/AirSend/cast.html';

// Tipos de petición que se vigilan. Los reproductores modernos piden los manifiestos de
// muchas formas: fetch normal (xmlhttprequest), desde un Worker o Service Worker, o dentro
// de un <iframe> incrustado. Si falta alguno, en esa web no se detecta nada.
const MEDIA_TYPES = ['media', 'xmlhttprequest', 'other', 'object'];

const HLS_RE = /\.m3u8(\?|$)/i;
const DASH_RE = /\.mpd(\?|$)/i;
const FILE_RE = /\.(mp4|webm|m4v|mov|mkv)(\?|$)/i;

// Muchos CDN sirven el manifiesto sin «.m3u8» en la ruta y con un content-type cualquiera
// (ok.ru/VK, y otros). No se puede ir por lista de dominios: en vez de eso se mira la forma
// del enlace, que es igual en todos: el reproductor lo pide por XHR, el enlace va firmado
// y caduca, y la respuesta es pequeña (un manifiesto es texto, no vídeo).
const SIGNED_RE = /[?&/](?:sig|signature|hmac|token|expires|expire|e|st)[=/]/i;
const PLAYLIST_HINT_RE = /(?:^|[/_.-])(?:master|index|playlist|manifest|chunklist|track|video|hls)(?:[/_.-]|$)/i;

/** ¿Tiene pinta de manifiesto HLS aunque la URL no lo diga? */
function looksLikeHls(url, type) {
  if (HLS_RE.test(url)) return true;
  // «media» no se excluye: algunos reproductores piden el manifiesto como media
  if (type && !MEDIA_TYPES.includes(type)) return false;
  if (FILE_RE.test(url) || DASH_RE.test(url)) return false;   // un archivo de verdad
  try {
    const u = new URL(url);
    // Firmado + nombre típico de manifiesto, o firmado sin ruta (el caso de ok.ru: todo
    // va en los parámetros). Son las dos formas en que llega un manifiesto «camuflado».
    if (!SIGNED_RE.test(u.search) && !SIGNED_RE.test(u.pathname)) return false;
    return PLAYLIST_HINT_RE.test(u.pathname) || u.pathname === '/' || u.pathname === '';
  } catch { return false; }
}

// El service worker se duerme y pierde la memoria: los enlaces se guardan en storage.session
const keyOf = (tabId) => `tab:${tabId}`;
async function getFound(tabId) {
  return (await chrome.storage.session.get(keyOf(tabId)))[keyOf(tabId)] || [];
}

// Cabeceras con las que la página pidió cada vídeo: el proxy las repite para que el servidor lo entregue
const sentHeaders = new Map();
chrome.webRequest.onSendHeaders.addListener((d) => {
  if (d.tabId < 0) return;
  const h = {};
  for (const { name, value } of d.requestHeaders || []) {
    const n = name.toLowerCase();
    if (n === 'referer' || n === 'origin' || n === 'user-agent') h[n] = value;
  }
  sentHeaders.set(d.requestId, h);
  if (sentHeaders.size > 300) sentHeaders.delete(sentHeaders.keys().next().value);
}, { urls: ['<all_urls>'], types: MEDIA_TYPES }, ['requestHeaders', 'extraHeaders']);

chrome.webRequest.onHeadersReceived.addListener(async (d) => {
  if (d.tabId < 0) return;
  const h = sentHeaders.get(d.requestId) || {};
  sentHeaders.delete(d.requestId);
  const ct = (d.responseHeaders || []).find((h) => h.name.toLowerCase() === 'content-type')?.value || '';
  // Subtítulos que pide la página (WebVTT/SRT): se mandan con el vídeo, como en la app
  if (/text\/vtt|application\/x-subrip/i.test(ct) || SUB_RE.test(d.url)) return addSub(d.tabId, d.url);
  const len = Number((d.responseHeaders || []).find((h) => h.name.toLowerCase() === 'content-length')?.value || 0);
  // Un manifiesto es texto y pesa poco; los trozos de vídeo pesan mucho. Así no se cuela
  // cada fragmento como si fuera el vídeo entero cuando el enlace no acaba en «.m3u8».
  const small = !len || len < 512 * 1024;
  // 1) Lo que el servidor declara es lo más fiable: si dice mpegurl/dash, es eso y punto.
  const hls = /mpegurl|vnd\.apple/i.test(ct) || HLS_RE.test(d.url)
    // 2) Si no lo declara, se deduce por la forma del enlace (manifiestos «camuflados»).
    || (small && !/^(video|audio|image)\//i.test(ct) && looksLikeHls(d.url, d.type));
  const dash = /dash\+xml/i.test(ct) || DASH_RE.test(d.url);

  // Vídeo completo descargado por trozos (vkvideo y otros piden rangos con fetch, no como
  // «media»). El «content-range» dice el tamaño total: «bytes 0-99/139600674». Mientras sea
  // el mismo archivo entero, la URL sin el parámetro de rango sirve para la tele.
  const range = (d.responseHeaders || []).find((x) => x.name.toLowerCase() === 'content-range')?.value || '';
  const total = Number(range.match(/\/(\d+)\s*$/)?.[1] || 0);
  const esVideo = /^video\//i.test(ct) || FILE_RE.test(d.url);
  // Un trozo suelto de YouTube y similares no vale: ahí cada trozo es un archivo distinto,
  // y se reconocen porque la URL lleva el rango dentro (no en la cabecera Range).
  const file = esVideo && (d.type === 'media' || total > 0);
  if (!hls && !dash && !file) return;

  // Si el rango va en la URL, se quita: así la tele puede pedir el archivo entero.
  let url = d.url;
  if (file && total > 0) {
    try {
      const u = new URL(url);
      for (const k of ['bytes', 'range', 'rn', 'rbuf']) u.searchParams.delete(k);
      url = u.href;
    } catch {}
  }
  const type = hls ? 'application/x-mpegurl'
    : dash ? 'application/dash+xml'
    : (ct.split(';')[0] || guessType(d.url));
  await addFound(d.tabId, { url, type, from: d.initiator || '', h, len: total || len });
},{ urls: ['<all_urls>'], types: MEDIA_TYPES }, ['responseHeaders']);

chrome.tabs.onUpdated.addListener(async (tabId, info, tab) => {
  if (info.url) {
    await chrome.storage.session.remove([keyOf(tabId), subsOf(tabId)]);
    vkDone.delete(tabId); // la lista se acaba de vaciar: hay que volver a pedirlos
  }
  // vkvideo/VK: al abrir un vídeo (también al pasar de uno a otro sin recargar) se pide la
  // versión H.264. La web móvil a veces solo reproduce VP9, que el Chromecast no lee.
  if (info.url || info.status === 'complete') vkFormats(tabId, info.url || tab?.url).catch(() => {});
});

// ---------- vkvideo / VK: pedir los enlaces H.264 del vídeo ----------
// La propia web los pide a «al_video.php?act=show»: trae HLS y MP4 (H.264), además del
// WebM VP9 que usa la versión móvil. Se añaden a la lista como si se hubieran visto pasar.
const VK_PAGE_RE = /^https:\/\/(?:m\.)?(?:vkvideo\.ru|vk\.com|vk\.ru)\/(?:.*[?&]z=)?video(-?\d+_\d+)/i;
const vkDone = new Map(); // tabId -> id del vídeo ya consultado (evita repetir la petición)

// vkvideo solo contesta si la petición lleva su Referer, y desde el fondo de la extensión
// un fetch no puede ponerlo. Esta regla lo añade solo a esta petición de la extensión
// (tabIds: ninguna pestaña), sin tocar lo que hagan las páginas.
const vkRefererRule = chrome.declarativeNetRequest.updateSessionRules({
  removeRuleIds: [1],
  addRules: [{
    id: 1,
    priority: 1,
    action: { type: 'modifyHeaders', requestHeaders: [{ header: 'referer', operation: 'set', value: 'https://vkvideo.ru/' }] },
    condition: { urlFilter: '|https://vkvideo.ru/al_video.php', tabIds: [chrome.tabs.TAB_ID_NONE], resourceTypes: ['xmlhttprequest'] }
  }]
}).catch(() => {});

async function vkFormats(tabId, pageUrl) {
  const id = VK_PAGE_RE.exec(pageUrl || '')?.[1];
  if (!id || vkDone.get(tabId) === id) return;
  vkDone.set(tabId, id);
  await vkRefererRule;
  const r = await fetch('https://vkvideo.ru/al_video.php?act=show', {
    method: 'POST',
    credentials: 'include',
    headers: { 'content-type': 'application/x-www-form-urlencoded', 'x-requested-with': 'XMLHttpRequest' },
    body: `act=show&al=1&video=${id}`,
    signal: AbortSignal.timeout(15000)
  });
  const text = (await r.text()).replace(/\\\//g, '/').replace(/\\u0026/g, '&');
  const get = (k) => text.match(new RegExp(`"${k}"\\s*:\\s*"(https:[^"]+)"`))?.[1];
  const h = { referer: 'https://vkvideo.ru/', origin: 'https://vkvideo.ru', 'user-agent': navigator.userAgent };
  const hls = get('hls') || get('hls_ondemand');
  if (hls) await addFound(tabId, { url: hls, type: 'application/x-mpegurl', from: pageUrl, h });
  // MP4 de la mejor calidad disponible, por si el receptor no lee HLS
  const best = ['2160', '1440', '1080', '720', '480', '360', '240', '144'].map((q) => get(`url${q}`)).find(Boolean);
  if (best) await addFound(tabId, { url: best, type: 'video/mp4', from: pageUrl, h });
  if (!hls && !best) vkDone.delete(tabId); // nada: se reintenta en la próxima carga
}
chrome.tabs.onRemoved.addListener((tabId) => {
  vkDone.delete(tabId);
  chrome.storage.session.remove([keyOf(tabId), subsOf(tabId)]);
});

// ---------- Subtítulos detectados (mismo formato que la app: {url, label, lang}) ----------
const SUB_RE = /\.(vtt|srt)(\?|$)/i;
const subsOf = (tabId) => `subs:${tabId}`;

function addSub(tabId, url) {
  queue = queue.then(async () => {
    const key = subsOf(tabId);
    const subs = (await chrome.storage.session.get(key))[key] || [];
    if (subs.some((s) => s.url === url)) return;
    // El idioma suele venir en el nombre: «…/es.vtt», «…_spa.vtt», «…-en.srt»
    const lang = (new URL(url).pathname.split('/').pop().match(/(?:^|[._-])([a-z]{2,3})\.(?:vtt|srt)$/i) || [])[1] || '';
    subs.push({ url, label: lang ? lang.toUpperCase() : `Subtítulos ${subs.length + 1}`, lang: lang.toLowerCase() });
    await chrome.storage.session.set({ [key]: subs.slice(-8) });
  }).catch(() => {});
  return queue;
}

/** Subtítulos del vídeo: los <track> del reproductor y, si no hay, los que pidió la página. */
async function tracksFor(tabId, fromPage) {
  if (fromPage?.length) return fromPage.slice(0, 8);
  const key = subsOf(tabId);
  return ((await chrome.storage.session.get(key))[key] || []).slice(0, 8);
}

// ---------- Cola para la tele ----------
// Como en la app: se van añadiendo vídeos y, al enviar uno a una tele que sabe seguir sola
// (AirRecied para LG, «proxy»), se le pasa la cola entera con las cabeceras de cada vídeo.
// La tele pasa sola al siguiente, así que el PC se puede apagar.
const QUEUE_MAX = 20;

async function getTvQueue() {
  return (await chrome.storage.local.get('tvQueue')).tvQueue || [];
}

async function addToTvQueue(media, page) {
  const list = await getTvQueue();
  if (list.some((q) => q.url === media.url)) return { ok: true, count: list.length, already: true };
  list.push({
    url: media.url,
    title: media.title || 'AirSend',
    mime: media.type || 'video/mp4',
    poster: media.poster || null,
    headers: pageHeaders(media, page),
    tracks: media.tracks || [],
    page: page || ''
  });
  const kept = list.slice(-QUEUE_MAX);
  await chrome.storage.local.set({ tvQueue: kept });
  return { ok: true, count: kept.length };
}

/** La cola tal como la espera el receptor en /api/load («queue»), igual que Backend.upNextFor. */
const queueForTv = (list) => list.map(({ url, title, mime, poster, headers, tracks }) => ({ url, title, mime, poster: poster || null, headers, tracks: tracks || [] }));

/** El enlace está firmado para el navegador que lo pidió (ok.ru/VK: «srcAg=CHROME»). */
function uaLocked(url) {
  return /[?&/]srcAg[=/](?!UNKNOWN)/i.test(url || '');
}

function guessType(url) {
  if (HLS_RE.test(url)) return 'application/x-mpegurl';
  if (DASH_RE.test(url)) return 'application/dash+xml';
  // Manifiestos sin «.m3u8» en la ruta (ok.ru/VK): si se mandan como video/mp4, el receptor
  // intenta leer la lista como si fuera un MP4 y falla con «malformed manifest».
  if (looksLikeHls(url, 'xmlhttprequest')) return 'application/x-mpegurl';
  if (/\.webm(\?|$)/i.test(url)) return 'video/webm';
  if (/\.mkv(\?|$)/i.test(url)) return 'video/x-matroska';
  return 'video/mp4';
}

// En cola: si dos avisos leen y escriben a la vez, uno borraría al otro
let queue = Promise.resolve();
function addFound(tabId, entry) {
  queue = queue.then(async () => {
    const found = await getFound(tabId);
    if (found.some((f) => f.url === entry.url)) return;
    found.push({ ...entry, at: Date.now() });
    await chrome.storage.session.set({ [keyOf(tabId)]: found.slice(-30) });
  }).catch(() => {});
  return queue;
}

async function pickMedia(tabId, src) {
  const found = (await getFound(tabId)).filter((f) => f.type !== 'page' && f.type !== 'player');
  if (/^https?:/i.test(src || '')) {
    // Si ese mismo enlace ya se vio pasar, se usa su tipo real (el del content-type) y sus
    // cabeceras, en vez de adivinarlo por la extensión del enlace.
    const known = found.find((f) => f.url === src);
    return known || { url: src, type: guessType(src) };
  }
  // Orden de preferencia:
  //  1. La lista HLS/DASH principal: trae todas las calidades y el receptor elige la que
  //     aguanta. Entre varias, la primera que se vio (las siguientes suelen ser variantes).
  //  2. Si no hay, el archivo de vídeo más grande: el más grande es el de más calidad.
  const manifests = found.filter((f) => f.type === 'application/x-mpegurl' || f.type === 'application/dash+xml');
  if (manifests.length) {
    // Del mismo vídeo suelen pasar varias listas: la principal («master», con todas las
    // calidades y pistas de audio), las de cada calidad, y a veces una de SOLO AUDIO.
    // Mandar esa última haría que la tele sonara sin imagen.
    const score = (f) => {
      const name = (() => { try { return new URL(f.url).pathname.split('/').filter(Boolean).pop() || ''; } catch { return ''; } })();
      if (/(^|[^a-z])(master|playlist|manifest)([^a-z]|$)/i.test(name)) return 3;
      if (/(^|[-_.])(a\d+|audio|aac|mp4a)[-_.]?[^/]*\.m3u8$/i.test(name) && !/(^|[-_.])v\d+/i.test(name)) return 0;
      return 1;
    };
    // A igualdad, la primera que se vio (las demás suelen ser sus calidades)
    return manifests.reduce((a, b) => (score(b) > score(a) ? b : a));
  }
  const files = found.filter((f) => /^video\//i.test(f.type));
  if (files.length) return files.reduce((a, b) => ((b.len || 0) > (a.len || 0) ? b : a));
  return found[found.length - 1] || null;
}

// ---------- Proxy en la nube (mismo formato de enlace firmado que cloudflare/worker.js y la app) ----------
const PROXY_TTL_S = 12 * 3600;

function toB64url(input) {
  const bytes = typeof input === 'string' ? new TextEncoder().encode(input) : new Uint8Array(input);
  let bin = '';
  for (const b of bytes) bin += String.fromCharCode(b);
  return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

async function sign(key, data) {
  const k = await crypto.subtle.importKey('raw', new TextEncoder().encode(key), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  return toB64url(await crypto.subtle.sign('HMAC', k, new TextEncoder().encode(data))).slice(0, 32);
}

async function proxyLink(media, page) {
  const { proxyUrl, proxyKey } = await chrome.storage.local.get(['proxyUrl', 'proxyKey']);
  if (!proxyUrl || !proxyKey) return null;
  return signedLink(proxyUrl, proxyKey, media, page);
}

// Programa de AirSend en este PC (pc-proxy/): se encuentra solo, sin configurar nada
const PC_PROXY = 'http://127.0.0.1:8787';
// Versión del programa del PC con la que se escribió esta extensión (= VERSION de pc-proxy/server.js).
// Súbela a la vez: al recargar la extensión, la ventana pedirá actualizar el programa.
const NEEDED_PC_VERSION = 12;
// La última publicada (la genera .github/workflows/pc-proxy.yml junto al zip)
const PC_LATEST_URL = 'https://github.com/alvarosiles/AirSend/releases/download/pc-latest/version.json';

/** Última versión publicada del programa del PC (se consulta como mucho cada 10 minutos). */
async function latestPcVersion() {
  const { pcLatest } = await chrome.storage.local.get('pcLatest');
  if (pcLatest && Date.now() - pcLatest.at < 10 * 60_000) return pcLatest.version;
  try {
    const r = await fetch(PC_LATEST_URL, { cache: 'no-store', signal: AbortSignal.timeout(5000) });
    const version = r.ok ? Number((await r.json()).version) || 0 : 0;
    if (version) await chrome.storage.local.set({ pcLatest: { version, at: Date.now() } });
    return version || pcLatest?.version || 0;
  } catch {
    return pcLatest?.version || 0;
  }
}
async function pcProxy() {
  try {
    const res = await fetch(`${PC_PROXY}/setup`, { signal: AbortSignal.timeout(1500) });
    return res.ok ? await res.json() : null;
  } catch {
    return null;
  }
}

async function pcLink(media, page) {
  const pc = await pcProxy();
  return pc ? signedLink(pc.url, pc.key, media, page) : null;
}

/** Cabeceras con las que la página pidió el vídeo (y, si faltan, las de la propia página). */
function pageHeaders(media, page) {
  const h = { ...(media.h || {}) };
  if (!h.referer && page) h.referer = page;
  if (!h.origin && page) h.origin = new URL(page).origin;
  // Hay CDN que firman el enlace para un navegador concreto (ok.ru/VK: «srcAg=CHROME») y
  // responden 400 a cualquier otro agente. Si no se capturó, va el de este navegador: sin
  // él, el proxy tampoco podría descargar el vídeo.
  if (!h['user-agent'] && navigator.userAgent) h['user-agent'] = navigator.userAgent;
  return h;
}

async function signedLink(base, key, media, page) {
  const h = pageHeaders(media, page);
  const data = toB64url(JSON.stringify({ u: media.url, h, e: Math.floor(Date.now() / 1000) + PROXY_TTL_S, m: media.type }));
  const parts = new URL(media.url).pathname.split('/').filter(Boolean);
  let name = (parts.pop() || 'media').replace(/[^\w.-]/g, '').slice(-60) || 'media';
  // Hay receptores (AirRecied) que deciden cómo leer el archivo por la extensión del enlace,
  // no por el content-type. Si es una lista HLS, el nombre tiene que acabar en «.m3u8»: si no,
  // intentan abrirla como un MP4 y fallan con «malformed manifest».
  if (/mpegurl/i.test(media.type || '') && !/\.m3u8$/i.test(name)) name = `${name.replace(/\.[^.]*$/, '')}.m3u8`;
  return `${base.replace(/\/+$/, '')}/p/${data}/${await sign(key, data)}/${name}`;
}

// Pide el vídeo por el Worker como lo haría el Chromecast: lista principal → calidad → primer trozo
async function testProxy(media, page, via) {
  const link = via === 'pc' ? await pcLink(media, page) : await proxyLink(media, page);
  if (!link) return { steps: [], error: via === 'pc' ? 'El programa de AirSend del PC no está abierto.' : 'Primero configura el proxy en la nube.' };
  const names = ['Lista principal', 'Calidad', 'Trozo de vídeo'];
  const steps = [];
  let url = link;
  for (let i = 0; i < 3 && url; i++) {
    let res, body = '';
    try {
      res = await fetch(url);
      body = (await res.text()).slice(0, 4000);
    } catch (e) {
      steps.push({ name: names[i], ok: false, detail: `Sin respuesta: ${e.message}` });
      break;
    }
    const playlist = body.startsWith('#EXTM3U');
    steps.push({
      name: names[playlist && i === 2 ? 1 : i], ok: res.ok,
      detail: res.ok ? (playlist ? 'Lista HLS correcta' : `${res.status} · ${res.headers.get('content-type') || 'sin tipo'}`) : `${res.status} · ${body.slice(0, 120)}`
    });
    if (!res.ok || !playlist) break;
    url = body.split(/\r?\n/).map((l) => l.trim()).find((l) => l && !l.startsWith('#')) || '';
  }
  return { steps };
}

async function pingProxy(proxyUrl, proxyKey) {
  try {
    const res = await fetch(`${proxyUrl.replace(/\/+$/, '')}/ping?sig=${await sign(proxyKey, 'ping')}`);
    return { ok: res.ok, text: await res.text() };
  } catch (e) {
    return { ok: false, text: `No se pudo conectar: ${e.message}` };
  }
}

// Nombres de las teles de la Wi-Fi: los busca el programa del PC, porque Chrome no los da.
// Cada búsqueda también pone al día el submenú del clic derecho.
async function fetchDevices() {
  let out;
  try {
    const res = await fetch(`${PC_PROXY}/devices`, { signal: AbortSignal.timeout(4000) });
    // 404: el programa está, pero es anterior a esta función
    out = res.status === 404 ? { error: 'oldpc' } : res.ok ? await res.json() : { error: 'nopc' };
  } catch {
    out = { error: 'nopc' };
  }
  buildMenu(out);
  return out;
}

// Envío directo desde el PC al receptor, como hace la app del móvil: sin ventana de Chrome.
// Si la web bloquea al receptor, se reintenta así:
//   1. directo · 2. el receptor se lo descarga solo con las cabeceras (si sabe: AirRecied para LG)
//   3. por la nube · 4. por el propio PC (el único en que el PC tiene que seguir encendido)
// Con una tele que sigue sola (AirRecied para LG) también se manda la cola: ver addToTvQueue.
const QUEUE_PC_VERSION = 6;

// ---- Audio en español por defecto ----
// Misma regla que cloudflare/worker.js (spanishScore): 3 latino · 2 español · 1 castellano · 0 otro
function spanishScore(language, name) {
  const lang = String(language || '').toLowerCase();
  const n = String(name || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
  const es = /^(es|spa|esp)\b/.test(lang) || /\b(espanol|spanish|castellano|latino)\b/.test(n);
  if (!es) return 0;
  if (/^es-(419|mx|la|us|ar|co|cl|pe|ve)/.test(lang) || /\b(latin|latino|lat|latam|mexico|419|america)\b/.test(n)) return 3;
  if (lang === 'es-es' || /\b(castellano|espana|spain|europe|europeo)\b/.test(n)) return 1;
  return 2;
}

/** ¿Lista HLS con varios idiomas cuyo audio por defecto no es el español? Los receptores que
 *  no dejan elegir pista (AirRecied) necesitan entonces pasar por el PC, que lo reordena. */
async function audioNeedsPc(media) {
  if (!/mpegurl/i.test(media.type || '') || uaLocked(media.url)) return false;
  try {
    const text = await (await fetch(media.url, { signal: AbortSignal.timeout(4000) })).text();
    const audios = text.split(/\r?\n/).filter((l) => /^#EXT-X-MEDIA:/.test(l) && /TYPE=AUDIO/.test(l));
    if (audios.length < 2) return false;
    const get = (l, k) => l.match(new RegExp(`(?<![A-Z-])${k}="?([^",]*)`))?.[1];
    const best = audios.reduce((a, b) => (spanishScore(get(b, 'LANGUAGE'), get(b, 'NAME')) > spanishScore(get(a, 'LANGUAGE'), get(a, 'NAME')) ? b : a));
    return spanishScore(get(best, 'LANGUAGE'), get(best, 'NAME')) > 0 && get(best, 'DEFAULT') !== 'YES';
  } catch {
    return false;
  }
}
// Mando (pausar, adelantar…) del vídeo que hay en la tele: lo hace el programa del PC
const CONTROL_PC_VERSION = 8; // 8: con volumen y «Salir»
const AUDIO_PC_VERSION = 10; // 10: lista de idiomas del vídeo y cambiar de uno a otro
// La tele dejó de poder descargar el vídeo a mitad: se reenvía a través del PC (que pide
// el vídeo con las cabeceras de la página) desde el punto donde iba.
async function retryViaPc(positionMs) {
  const { nowPlaying } = await chrome.storage.local.get('nowPlaying');
  if (!nowPlaying?.media?.url) return { error: 'No hay ningún vídeo que reenviar.' };
  const local = await pcLink(nowPlaying.media, nowPlaying.page);
  if (!local) return { error: 'Abre el programa de AirSend del PC.' };
  try {
    const r = await fetch(`${PC_PROXY}/send`, {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ id: nowPlaying.id, media: {
        url: local, type: nowPlaying.media.type, title: nowPlaying.title || 'AirSend',
        poster: nowPlaying.media.poster, tracks: nowPlaying.media.tracks,
        time: Math.max(0, Math.floor((positionMs || nowPlaying.lastPos || 0) / 1000) - 5) // unos segundos antes
      } }),
      signal: AbortSignal.timeout(45000)
    });
    const out = await r.json();
    if (out.ok) await chrome.storage.local.set({ nowPlaying: { ...nowPlaying, viaPc: true, at: Date.now() } });
    return out;
  } catch {
    return { error: 'El programa de AirSend del PC no responde.' };
  }
}

async function controlTv(action, value) {
  const { nowPlaying } = await chrome.storage.local.get('nowPlaying');
  if (!nowPlaying) return { none: true };
  const pc = await pcProxy();
  if (!pc) return { ...nowPlaying, error: 'nopc' };
  if ((pc.version || 0) < (action === 'audio' ? AUDIO_PC_VERSION : CONTROL_PC_VERSION)) return { ...nowPlaying, error: 'oldpc' };
  try {
    const r = await fetch(`${PC_PROXY}/control`, {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ id: nowPlaying.id, action, value }),
      signal: AbortSignal.timeout(10000)
    });
    const out = await r.json();
    // Última posición buena: si la tele falla, vuelve a 0 y así se sabe desde dónde seguir
    if (!out.error && out.positionMs > 0 && ['PLAYING', 'PAUSED', 'BUFFERING'].includes(out.state)) {
      await chrome.storage.local.set({ nowPlaying: { ...nowPlaying, lastPos: out.positionMs } });
    }
    return { ...nowPlaying, ...out, title: out.title || nowPlaying.title || '' };
  } catch {
    return { ...nowPlaying, error: 'El programa de AirSend del PC no responde.' };
  }
}
async function sendToDevice(id, media, page, tabId) {
  const device = ((await fetchDevices()).devices || []).find((d) => d.id === id);
  // Portada y subtítulos (AirRecied los usa; Chromecast la portada)
  const tracks = await tracksFor(tabId, media.tracks);
  const base = { ...media, ...(tracks.length ? { tracks } : {}) };
  delete base.h; delete base.proxied; delete base.local;
  const pending = device?.proxy ? (await getTvQueue()).filter((q) => q.url !== media.url) : [];
  const canQueue = pending.length > 0 && ((await pcProxy())?.version || 0) >= QUEUE_PC_VERSION;

  // Enlaces atados al navegador que los pidió: el receptor, con su propio User-Agent, recibe
  // un 400 siempre. Se ahorra ese intento (45 s de espera) y se va directo al proxy.
  const tries = uaLocked(media.url) ? [] : [{ url: media.url }];
  if (device?.proxy) tries.push({ url: media.url, headers: pageHeaders(media, page), viaTv: true });
  const proxied = await proxyLink(media, page);
  if (proxied) tries.push({ url: proxied, viaCloud: true });
  const local = await pcLink(media, page);
  if (local) tries.push({ url: local, viaPc: true });
  // Si el enlace está atado al navegador y no hay ningún proxy, se intenta igual el directo:
  // mejor probar y fallar que no enviar nada.
  if (!tries.length) tries.push({ url: media.url });
  // AirRecied y similares no dejan elegir el idioma: si el español no es el audio por defecto,
  // primero por el PC, que pone el español delante (el Chromecast lo elige él solo)
  if (device?.source === 'mymultimedia' && local && await audioNeedsPc(media)) {
    const pc = tries.findIndex((t) => t.viaPc);
    if (pc > 0) tries.unshift(...tries.splice(pc, 1));
  }
  let last = 'No se pudo enviar.';
  for (const t of tries) {
    // La cola solo tiene sentido cuando la tele se descarga los vídeos sola (con sus cabeceras)
    const withQueue = canQueue && (t.viaTv || !t.viaPc && !t.viaCloud);
    try {
      const r = await fetch(`${PC_PROXY}/send`, {
        method: 'POST', headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          id,
          media: {
            ...base, url: t.url,
            // Las cabeceras van siempre que la tele sabe usarlas: así el directo también sigue con la cola
            ...(t.headers || withQueue ? { headers: t.headers || pageHeaders(media, page) } : {}),
            ...(withQueue ? { queue: queueForTv(pending) } : {})
          }
        }),
        signal: AbortSignal.timeout(45000)
      });
      const out = await r.json();
      if (out.ok) {
        // La tele ya tiene la cola: se vacía aquí, igual que la app la va soltando al avanzar
        if (withQueue) await chrome.storage.local.set({ tvQueue: [] });
        // El mando de la ventana de AirSend controla el último vídeo enviado
        // También el vídeo y la página: si la tele deja de poder descargarlo a mitad, el mando
        // lo puede reenviar por el PC desde donde iba
        await chrome.storage.local.set({ nowPlaying: {
          id, name: out.device || device?.name || '', title: media.title || '', at: Date.now(),
          media: { url: media.url, type: media.type, h: media.h, title: media.title, poster: media.poster, tracks: base.tracks },
          page, viaPc: !!t.viaPc
        } });
        return { ...out, viaPc: !!t.viaPc, viaCloud: !!t.viaCloud, viaTv: !!t.viaTv, queued: withQueue ? pending.length : 0 };
      }
      last = out.error || last;
    } catch {
      last = 'El programa de AirSend del PC no responde.';
      break;
    }
  }
  return { error: last };
}

// ---------- Clic derecho → «Enviar a la tele (AirSend)» → dispositivos ----------
// El «Enviar…» de Chrome no se puede ampliar; este es un menú propio en el mismo sitio.
// Chrome no avisa al abrir el menú, así que la lista se refresca al cambiar de pestaña.
const MENU_CONTEXTS = ['page', 'frame', 'video', 'link'];
let menuSig = null;
let menuQueue = Promise.resolve();

// Altavoces (Google Home, Nest Mini…): reciben vídeo/audio, pero no tienen pantalla
const isSpeaker = (d) => /home|mini|audio|speaker|nest/i.test(`${d.model} ${d.name}`) && !/tv|chromecast|display|hub/i.test(d.model || '');

// Tres envíos distintos, cada uno con los dispositivos que lo admiten:
//   vídeo   → el vídeo detectado en la página (todos)
//   página  → la tele abre su propia copia de la dirección (Chromecast con DashCast;
//             My Multimedia con su /api/web)
//   pestaña → se duplica lo que se ve en el PC, con la sesión iniciada
//             (My Multimedia por WebRTC; Chromecast con la lista de Chrome)
const KINDS = [
  ['video', 'Enviar vídeo', () => true],
  ['page', 'Enviar página', (d) => !isSpeaker(d)],
  // Las teles LG con AirRecied (webOS 3.5) no pueden mostrar pestañas en directo (WebRTC)
  ['tab', 'Enviar pestaña', (d) => !isSpeaker(d) && !/webos/i.test(d.model || '')]
];

function buildMenu(res) {
  const devices = res?.devices || [];
  const sig = JSON.stringify([res?.error || '', devices.map((d) => [d.id, d.name, d.source, d.host, !!d.proxy])]);
  if (sig === menuSig) return menuQueue;
  menuSig = sig;
  menuQueue = menuQueue.then(async () => {
    await chrome.contextMenus.removeAll();
    const add = (p) => chrome.contextMenus.create({ contexts: MENU_CONTEXTS, ...p }, () => void chrome.runtime.lastError);
    add({ id: 'airsend', title: 'Enviar a la tele (AirSend)' });
    const problem = res?.error === 'nopc' ? 'Abre el programa de AirSend del PC para ver tus teles'
      : res?.error === 'oldpc' ? 'Actualiza el programa de AirSend del PC'
      : !devices.length ? 'No hay ninguna tele en la Wi‑Fi' : '';
    if (problem) add({ id: 'none', parentId: 'airsend', title: problem, enabled: false });
    for (const [kind, title, fits] of KINDS) {
      const list = devices.filter(fits);
      if (!list.length) continue;
      add({ id: kind, parentId: 'airsend', title });
      for (const d of list) add({ id: `${kind}:${d.id}`, parentId: kind, title: d.name });
    }
    const { mirror } = await chrome.storage.session.get('mirror');
    const mirroring = mirror?.phase === 'connecting' || mirror?.phase === 'live';
    // Cola: luego se pasa entera a la tele al enviarle un vídeo (si sabe seguir sola)
    if (devices.some((d) => d.proxy)) add({ id: 'enqueue', parentId: 'airsend', title: 'Añadir el vídeo a la cola de la tele' });
    add({ id: 'sep', parentId: 'airsend', type: 'separator' });
    add({ id: 'stopmirror', parentId: 'airsend', title: 'Dejar de enviar la pestaña', visible: mirroring });
    add({ id: 'refresh', parentId: 'airsend', title: 'Buscar dispositivos de nuevo' });
  }).catch(() => {});
  return menuQueue;
}

let lastRefresh = 0;
function refreshMenu(force) {
  if (!force && Date.now() - lastRefresh < 20000) return;
  lastRefresh = Date.now();
  fetchDevices();
}
chrome.runtime.onInstalled.addListener(() => { menuSig = null; refreshMenu(true); });
chrome.runtime.onStartup.addListener(() => refreshMenu(true));
chrome.tabs.onActivated.addListener(() => refreshMenu());
chrome.windows.onFocusChanged.addListener(() => refreshMenu());

// Avisa a la pestaña (mensaje en pantalla y pausa del vídeo). Si AirSend no está activo en ella
// (pestaña abierta antes de instalar/recargar la extensión), el aviso sale como notificación de Windows.
function tellTab(tabId, msg) {
  chrome.tabs.sendMessage(tabId, msg, { frameId: 0 }).catch(() => {
    chrome.notifications.create({ type: 'basic', iconUrl: 'icon128.png', title: 'AirSend', message: msg.text });
  });
  if (msg.type === 'airsend:sent') chrome.tabs.sendMessage(tabId, msg).catch(() => {});
}

// ---------- Duplicar la pestaña en un receptor My Multimedia ----------
// Como la extensión AirRecied Cast: se captura la pestaña tal cual (imagen y sonido, con la
// sesión iniciada) y se manda por WebRTC a /api/mirror/... del receptor, desde offscreen.js.
const OFFSCREEN_URL = 'offscreen.html';

async function hasOffscreen() {
  const ctx = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'], documentUrls: [chrome.runtime.getURL(OFFSCREEN_URL)] });
  return ctx.length > 0;
}

async function setMirror(state) {
  const { mirror: before } = await chrome.storage.session.get('mirror');
  await chrome.storage.session.set({ mirror: state });
  const on = state.phase === 'connecting' || state.phase === 'live';
  // Puntero dibujado en la página (la captura no incluye el ratón)
  if (before?.tabId != null && (!on || before.tabId !== state.tabId)) setPointer(before.tabId, false);
  if (on && state.tabId != null) setPointer(state.tabId, true);
  chrome.action.setBadgeText({ text: on ? (state.phase === 'live' ? 'ON' : '…') : '' });
  chrome.action.setBadgeBackgroundColor({ color: '#2878FF' });
  chrome.contextMenus.update('stopmirror', { visible: on }, () => void chrome.runtime.lastError);
  if (!on && await hasOffscreen()) await chrome.offscreen.closeDocument().catch(() => {});
}

async function mirrorTab(tab, device) {
  const say = (text) => tellTab(tab.id, { type: 'airsend:toast', text });
  if (!/^(https?|file):/i.test(tab.url || '')) return say('Esta pestaña no se puede enviar (páginas internas de Chrome).');
  const update = 'Para enviar la pestaña, actualiza el programa de AirSend del PC (descárgalo desde la ventana de AirSend).';

  // Chromecast: el programa del PC le abre una página receptora y hace de buzón para WebRTC
  if (device.source === 'cast') {
    const pc = await pcProxy();
    if (!pc) return say('Abre el programa de AirSend del PC para enviar a la tele.');
    if ((pc.version || 0) < TAB_CAST_PC_VERSION) return say(update);
    return startMirror(tab, device, { via: 'cast', deviceId: device.id });
  }

  if (!device.host) return say(update);
  try {
    const pair = await mmPair(device);
    if (pair.error) return say(pair.error);
    return startMirror(tab, device, { via: 'mm', host: device.host, token: pair.token });
  } catch (e) {
    say(`No se pudo enviar la pestaña: ${e.message || e}`);
  }
}

// Emparejar con un My Multimedia sin código, como al enviar vídeos desde el PC → { token } o { error }
async function mmPair(device) {
  let pair;
  try {
    pair = await fetch(`http://${device.host}/api/pair`, {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ pin: '' }), signal: AbortSignal.timeout(8000)
    });
  } catch {
    return { error: `No se encuentra «${device.name}» en la Wi‑Fi. ¿Sigue activo el receptor?` };
  }
  const out = await pair.json().catch(() => ({}));
  if (pair.status === 401) return { error: `«${device.name}» pide un código. Desactiva el código en sus ajustes y vuelve a probar.` };
  if (!pair.ok || !out.token) return { error: out.error || `«${device.name}» rechazó la conexión.` };
  return { token: out.token };
}


// Captura la pestaña y la pasa al documento oculto, que la envía por WebRTC
const TAB_CAST_PC_VERSION = 4;
async function startMirror(tab, device, channel) {
  const say = (text) => tellTab(tab.id, { type: 'airsend:toast', text });
  try {
    // El permiso para capturar viene del clic en el menú
    const streamId = await chrome.tabCapture.getMediaStreamId({ targetTabId: tab.id });
    await setMirror({ phase: 'connecting', tabId: tab.id, device: device.name });
    if (!await hasOffscreen()) {
      await chrome.offscreen.createDocument({ url: OFFSCREEN_URL, reasons: ['USER_MEDIA'], justification: 'Capturar la pestaña y enviarla al receptor por WebRTC' });
    }
    await chrome.runtime.sendMessage({ target: 'offscreen', type: 'start', streamId, title: tab.title || '', ...channel });
    say(`Enviando esta pestaña a ${device.name}…`);
  } catch (e) {
    await setMirror({ phase: 'idle' });
    say(`No se pudo enviar la pestaña: ${e.message || e}`);
  }
}

async function stopMirror() {
  if (await hasOffscreen()) await chrome.runtime.sendMessage({ target: 'offscreen', type: 'stop' }).catch(() => {});
  await setMirror({ phase: 'idle' });
}

function setPointer(tabId, on) {
  chrome.tabs.sendMessage(tabId, { type: 'airsend:pointer', on }, { frameId: 0 }).catch(() => {});
}

// Al navegar a otra página dentro de la pestaña duplicada, el puntero se vuelve a poner
chrome.tabs.onUpdated.addListener(async (tabId, info) => {
  if (info.status !== 'complete') return;
  const { mirror } = await chrome.storage.session.get('mirror');
  if (mirror?.tabId === tabId && (mirror.phase === 'connecting' || mirror.phase === 'live')) setPointer(tabId, true);
});

// Si se cierra la pestaña que se está enviando, se detiene todo
chrome.tabs.onRemoved.addListener(async (tabId) => {
  const { mirror } = await chrome.storage.session.get('mirror');
  if (mirror?.tabId === tabId && mirror.phase !== 'idle') stopMirror();
});

// «Enviar página»: la tele abre su propia copia de la dirección, sin la sesión iniciada de
// este navegador. Chromecast: la abre el programa del PC (desde la versión 3) con DashCast.
// My Multimedia: su app la abre en su navegador (/api/web). Lo usan el menú y la ventana.
const PAGE_PC_VERSION = 3;
async function pushPage(device, url, title) {
  if (!/^https?:/i.test(url || '')) return { error: 'Esta página no se puede enviar a la tele.' };
  const update = 'Para enviar páginas, actualiza el programa de AirSend del PC (descárgalo desde la ventana de AirSend).';

  if (device.source === 'mymultimedia') {
    if (!device.host) return { error: update };
    const pair = await mmPair(device);
    if (pair.error) return pair;
    try {
      const r = await fetch(`http://${device.host}/api/web`, {
        method: 'POST', headers: { 'content-type': 'application/json', 'X-Auth-Token': pair.token },
        body: JSON.stringify({ url, title: title || '' }), signal: AbortSignal.timeout(8000)
      });
      const out = await r.json().catch(() => ({}));
      // 404: la app del receptor es anterior a «Enviar página»
      if (r.status === 404) return { error: `Actualiza la app de «${device.name}»: su versión no sabe abrir páginas.` };
      return r.ok ? { ok: true, text: `Mostrando la página en ${out.device || device.name}` } : { error: out.error || 'No se pudo enviar la página.' };
    } catch {
      return { error: `«${device.name}» no responde.` };
    }
  }

  const pc = await pcProxy();
  if (!pc) return { error: 'Abre el programa de AirSend del PC para enviar a la tele.' };
  if ((pc.version || 0) < PAGE_PC_VERSION) return { error: update };
  try {
    const r = await fetch(`${PC_PROXY}/send`, {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ id: device.id, page: url }),
      signal: AbortSignal.timeout(30000)
    });
    const out = await r.json();
    return out.ok ? { ok: true, text: `Mostrando la página en ${out.device || device.name}` } : { error: out.error || 'No se pudo enviar la página.' };
  } catch {
    return { error: 'El programa de AirSend del PC no responde.' };
  }
}

// Desde el menú del clic derecho: la pestaña actual, con avisos en la propia página
async function sendPage(tab, device) {
  const say = (text) => tellTab(tab.id, { type: 'airsend:toast', text });
  say(`Enviando la página a ${device.name}…`);
  const res = await pushPage(device, tab.url, tab.title);
  say(res.error || res.text);
}

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === 'refresh') return refreshMenu(true);
  if (info.menuItemId === 'stopmirror') return stopMirror();
  if (info.menuItemId === 'enqueue' && tab?.id) return enqueueFromTab(tab, info.mediaType === 'video' ? info.srcUrl : '');
  // «tipo:id del dispositivo» (el id puede llevar «:», como «mm:salon»)
  const item = String(info.menuItemId);
  const cut = item.indexOf(':');
  const kind = item.slice(0, cut);
  const devId = item.slice(cut + 1);
  if (cut < 0 || !tab?.id || !KINDS.some(([k]) => k === kind)) return;

  // El estado del menú puede ser de hace un rato: se usa el último que se conozca del dispositivo
  const devices = (await fetchDevices()).devices || [];
  const device = devices.find((d) => d.id === devId);
  const name = device?.name || 'la tele';
  if (!device) return tellTab(tab.id, { type: 'airsend:toast', text: 'Ese dispositivo ya no está en la Wi‑Fi. Vuelve a abrir el menú.' });

  if (kind === 'page') return sendPage(tab, device);
  if (kind === 'tab') return mirrorTab(tab, device);

  const src = info.mediaType === 'video' ? info.srcUrl : '';
  const media = await pickMedia(tab.id, src);
  if (!media) {
    return tellTab(tab.id, { type: 'airsend:toast', text: 'No encontré ningún vídeo en esta página. Dale a reproducir unos segundos, o usa «Enviar página» o «Enviar pestaña».' });
  }
  tellTab(tab.id, { type: 'airsend:toast', text: `Enviando a ${name}…` });
  // Minuto por el que va el vídeo, para que la tele siga desde ahí
  const now = await Promise.race([
    chrome.tabs.sendMessage(tab.id, { type: 'airsend:now' }).catch(() => null),
    new Promise((r) => setTimeout(() => r(null), 800))
  ]);
  const page = tab.url;
  const res = await sendToDevice(devId, {
    ...media,
    time: now?.time || 0,
    poster: now?.poster || '',
    tracks: now?.tracks || [],
    title: tab.title || '',
    page
  }, page, tab.id);
  if (res.error) return tellTab(tab.id, { type: 'airsend:toast', text: res.error });
  tellTab(tab.id, { type: 'airsend:sent', text: sentText(res, name) });
});

/** El aviso tras enviar, igual en el menú y en el botón «Enviar» de la página. */
function sentText(res, name) {
  const tv = res.device || name;
  const more = res.queued ? ` Después seguirá sola con ${res.queued} vídeo${res.queued > 1 ? 's' : ''} de la cola.` : '';
  return (res.viaTv ? `Reproduciendo en ${tv}: la tele se descarga el vídeo sola (puedes apagar el PC).`
    : res.viaPc ? `Reproduciendo en ${tv} a través de este PC (déjalo encendido).`
    : res.viaCloud ? `Reproduciendo en ${tv} por el proxy en la nube.`
    : `Reproduciendo en ${tv}.`) + more;
}

// «Añadir el vídeo a la cola de la tele» desde el clic derecho
async function enqueueFromTab(tab, src) {
  const say = (text) => tellTab(tab.id, { type: 'airsend:toast', text });
  const media = await pickMedia(tab.id, src);
  if (!media) return say('No encontré ningún vídeo en esta página. Dale a reproducir unos segundos y vuelve a probar.');
  const now = await Promise.race([
    chrome.tabs.sendMessage(tab.id, { type: 'airsend:now' }).catch(() => null),
    new Promise((r) => setTimeout(() => r(null), 800))
  ]);
  const tracks = await tracksFor(tab.id, now?.tracks);
  const res = await addToTvQueue({ ...media, title: tab.title || '', poster: now?.poster || '', tracks }, tab.url);
  say(res.already ? `Este vídeo ya está en la cola (${res.count}).` : `Añadido a la cola de la tele (${res.count}). Se le pasará al enviarle un vídeo.`);
}

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  // Estado de la duplicación de pestaña, desde offscreen.js
  if (msg?.type === 'airsend:mirror-state') {
    (async () => {
      const { mirror = {} } = await chrome.storage.session.get('mirror');
      await setMirror({ ...mirror, phase: msg.phase });
      if (mirror.tabId != null) {
        const text = msg.phase === 'live' ? `Mostrando esta pestaña en ${mirror.device}`
          : msg.error ? msg.error : 'Se dejó de enviar la pestaña.';
        tellTab(mirror.tabId, { type: 'airsend:toast', text });
      }
    })();
    return;
  }
  // Página o reproductor incrustado donde hay un vídeo (enlace de referencia)
  if (msg?.type === 'airsend:frame') {
    addFound(sender.tab.id, {
      url: msg.url, title: msg.title,
      type: sender.frameId === 0 ? 'page' : 'player',
      from: sender.frameId === 0 ? '' : sender.tab.url || ''
    });
    return;
  }
  // ¿Hay algún vídeo detectado por red en esta pestaña? Lo pregunta content.js cuando no
  // encuentra ningún <video> en el DOM, para decidir si saca el botón «huérfano».
  if (msg?.type === 'airsend:hasmedia') {
    (async () => {
      const found = await getFound(sender.tab?.id);
      reply({ has: found.some((f) => f.type !== 'page' && f.type !== 'player') });
    })();
    return true;
  }
  // Mando de la ventana de AirSend: estado del vídeo en la tele y órdenes
  if (msg?.type === 'airsend:control') {
    controlTv(msg.action || 'status', msg.value).then(reply);
    return true;
  }
  if (msg?.type === 'airsend:control-retry') {
    retryViaPc(msg.position).then(reply);
    return true;
  }
  // Elegir en la ventana qué dispositivo controla el mando (Chromecast, My Multimedia…),
  // aunque el vídeo no se haya enviado desde aquí
  if (msg?.type === 'airsend:control-target') {
    (async () => {
      const { nowPlaying } = await chrome.storage.local.get('nowPlaying');
      if (nowPlaying?.id !== msg.id) {
        await chrome.storage.local.set({ nowPlaying: { id: msg.id, name: msg.name || '', title: '', at: Date.now(), picked: true } });
      }
      reply(await controlTv('status'));
    })();
    return true;
  }
  if (msg?.type === 'airsend:control-forget') {
    chrome.storage.local.remove('nowPlaying').then(() => reply({ ok: true }));
    return true;
  }
  if (msg?.type === 'airsend:resolve') {
    (async () => {
      const media = await pickMedia(sender.tab.id, msg.src);
      if (!media) return reply({ media: null });
      const [proxied, local] = await Promise.all([proxyLink(media, msg.page).catch(() => null), pcLink(media, msg.page).catch(() => null)]);
      // h: cabeceras con las que la página pidió el vídeo (para que la tele se lo descargue sola)
      reply({ media: { url: media.url, type: media.type, h: media.h, proxied, local } });
    })();
    return true;
  }
  if (msg?.type === 'airsend:test') {
    testProxy(msg.media, msg.page, msg.via).then(reply);
    return true;
  }
  // «Enviar página» desde la ventana de AirSend: una dirección concreta de la lista
  if (msg?.type === 'airsend:sendpage') {
    (async () => {
      const device = ((await fetchDevices()).devices || []).find((d) => d.id === msg.id);
      reply(device ? await pushPage(device, msg.url, msg.title) : { error: 'Ese dispositivo ya no está en la Wi‑Fi.' });
    })();
    return true;
  }
  if (msg?.type === 'airsend:devices') {
    fetchDevices().then(reply);
    return true;
  }
  if (msg?.type === 'airsend:send') {
    sendToDevice(msg.id, msg.media, msg.page, sender.tab?.id).then((res) => reply(res.error ? res : { ...res, text: sentText(res, '') }));
    return true;
  }
  // Cola de la tele: añadir (desde la página o la ventana), ver, quitar uno o vaciarla
  if (msg?.type === 'airsend:enqueue') {
    (async () => {
      const tracks = await tracksFor(sender.tab?.id ?? msg.tabId, msg.media.tracks);
      reply(await addToTvQueue({ ...msg.media, tracks }, msg.page));
    })();
    return true;
  }
  if (msg?.type === 'airsend:queue') {
    (async () => {
      let list = await getTvQueue();
      if (msg.op === 'remove') list = list.filter((q) => q.url !== msg.url);
      if (msg.op === 'clear') list = [];
      if (msg.op) await chrome.storage.local.set({ tvQueue: list });
      reply({ queue: list });
    })();
    return true;
  }
  if (msg?.type === 'airsend:pcstatus') {
    Promise.all([pcProxy(), latestPcVersion()]).then(([pc, published]) => {
      const version = pc?.version || 0;
      // Lo que hay que tener: la que pide esta extensión o la última publicada, la mayor
      const latest = Math.max(NEEDED_PC_VERSION, published);
      reply({
        url: pc?.url || null,
        version, latest, published,
        needed: NEEDED_PC_VERSION,
        outdated: Boolean(pc?.url) && version < latest
      });
    });
    return true;
  }
  if (msg?.type === 'airsend:ping') {
    pingProxy(msg.proxyUrl, msg.proxyKey).then(reply);
    return true;
  }
  // Respaldo cuando la página no deja cargar el SDK de Cast
  if (msg?.type === 'airsend:open') {
    chrome.tabs.create({ url: `${SENDER_URL}#${encodeURIComponent(JSON.stringify(msg.data))}`, index: sender.tab.index + 1 })
      .then(() => reply({ ok: true }));
    return true;
  }
});
