(() => {
  if (window.__airsend) return;
  window.__airsend = true;

  const CAST_SVG = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 8V6a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-6"/><path d="M2 12a9 9 0 0 1 8 8"/><path d="M2 16a5 5 0 0 1 4 4"/><path d="M2 20h.01"/></svg>';

  // Todo dentro de un Shadow DOM: los estilos de la página no afectan al botón y viceversa
  const host = document.createElement('airsend-overlay');
  host.style.cssText = 'all: initial; position: fixed; inset: 0; pointer-events: none; z-index: 2147483647;';
  const root = host.attachShadow({ mode: 'closed' });
  root.innerHTML = `<style>
    .btn { position: fixed; pointer-events: auto; display: flex; align-items: center; gap: 6px; height: 36px; padding: 0 12px 0 10px;
      border: 0; border-radius: 999px; cursor: pointer; color: #fff; font: 700 13px/1 system-ui, sans-serif;
      background: linear-gradient(180deg, #4595FF, #2878FF); box-shadow: 0 6px 20px rgba(0,0,0,.4);
      opacity: .85; transition: opacity .2s, transform .15s; }
    .btn:hover { opacity: 1; transform: scale(1.05); }
    .btn:active { transform: scale(.95); }
    .toast { position: fixed; left: 50%; bottom: 24px; transform: translateX(-50%); max-width: 90vw; padding: 12px 16px; border-radius: 14px;
      background: #171D28; color: #F5F7FA; font: 500 14px/1.4 system-ui, sans-serif; box-shadow: 0 10px 30px rgba(0,0,0,.5);
      border: 1px solid rgba(255,255,255,.12); pointer-events: auto; }

    /* Panel de dispositivos: el mismo aspecto que la ventana de AirSend */
    .back { position: fixed; inset: 0; background: rgba(0,0,0,.5); pointer-events: auto; display: grid; place-items: center;
      font: 400 14px/1.45 system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif; }
    .panel { width: 330px; max-width: 92vw; max-height: 80vh; overflow: auto; padding: 16px; border-radius: 18px; color: #F5F7FA;
      background: radial-gradient(120% 50% at 50% -10%, rgba(40,120,255,.16), transparent 60%), #0E131C;
      border: 1px solid rgba(255,255,255,.12); box-shadow: 0 24px 60px rgba(0,0,0,.6); }
    .head { display: flex; align-items: center; gap: 8px; margin-bottom: 12px; }
    .head b { flex: 1; font-size: 15px; font-weight: 700; }
    .x { width: 28px; height: 28px; flex: none; display: grid; place-items: center; cursor: pointer; border: 0; border-radius: 8px;
      background: transparent; color: #929BAA; font: 400 20px/1 system-ui, sans-serif; }
    .x:hover { background: rgba(255,255,255,.08); color: #F5F7FA; }
    .devs { display: grid; gap: 8px; }
    .dev { display: flex; align-items: center; gap: 10px; width: 100%; padding: 11px 12px; border-radius: 13px; cursor: pointer; text-align: left;
      background: rgba(255,255,255,.04); border: 1px solid rgba(255,255,255,.1); color: #F5F7FA; font: inherit;
      transition: background .15s, border-color .15s; }
    .dev:hover { background: rgba(40,120,255,.14); border-color: rgba(40,120,255,.45); }
    .dev svg { flex: none; color: #4595FF; }
    .dev span { flex: 1; min-width: 0; }
    .dev b { display: block; font-size: 13.5px; font-weight: 650; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .dev small { color: #929BAA; font-size: 11.5px; }
    .note { margin: 12px 0 0; color: #929BAA; font-size: 12px; }
    .note.bad { color: #FF8F9B; }
    .alt { width: 100%; margin-top: 10px; height: 34px; border-radius: 10px; cursor: pointer; font: 650 12.5px system-ui, sans-serif;
      color: #fff; border: 0; background: linear-gradient(180deg, #4595FF, #2878FF); }
    a.alt.dl { display: flex; align-items: center; justify-content: center; text-decoration: none; box-sizing: border-box; }
    .alt.ghost { background: none; border: 1px solid rgba(255,255,255,.18); color: #F5F7FA; }
    .spin { display: grid; place-items: center; padding: 22px 0; color: #929BAA; font-size: 13px; }
  </style>`;

  const buttons = new Map();
  let reported = '';

  // ---- Buscar vídeos también dentro de Shadow DOM -------------------------
  // querySelectorAll no atraviesa shadow roots, y un MutationObserver sobre el documento
  // tampoco ve lo que pasa dentro: hay que observar cada raíz por separado. Sin esto, los
  // reproductores que se montan en Shadow DOM nunca llegan a tener botón.
  const seenRoots = new WeakSet();
  let pendingScan = 0;
  const observer = new MutationObserver(() => {
    if (pendingScan) return;
    pendingScan = setTimeout(() => { pendingScan = 0; scan(); }, 300);
  });

  function watchRoot(root) {
    if (!root || seenRoots.has(root)) return;
    seenRoots.add(root);
    observer.observe(root, { childList: true, subtree: true });
  }

  function deepVideos(root = document, out = []) {
    for (const el of root.querySelectorAll('*')) {
      if (el.localName === 'video') out.push(el);
      if (el.shadowRoot) { watchRoot(el.shadowRoot); deepVideos(el.shadowRoot, out); }
    }
    return out;
  }

  // ---- Botón «huérfano» ---------------------------------------------------
  // Última red: la pestaña tiene un vídeo detectado por red (HLS/MP4) pero no hay ningún
  // <video> en el DOM. Pasa en webs que montan el reproductor por completo con JS. El botón
  // se ancla al hueco del reproductor; al enviar, resolve() usa el enlace ya detectado.
  const ORPHAN = Symbol('orphan');
  let orphanBox = null;

  const orphanAlive = () => Boolean(orphanBox?.isConnected);
  const orphanRect = () => (orphanBox ? orphanBox.getBoundingClientRect() : new DOMRect());

  // El hueco del reproductor. No vale coger el bloque más grande: ese suele ser el contenedor
  // de toda la página. Se busca el que más se parece a un reproductor (16:9) y, a igualdad,
  // el más interno, que es el propio hueco del vídeo y no lo que lo envuelve.
  function findPlayerBox() {
    let best = null;
    let bestScore = -1;
    for (const el of document.body?.querySelectorAll('div, section, main, article') || []) {
      const r = el.getBoundingClientRect();
      if (r.width < 320 || r.height < 180) continue;
      if (r.top > innerHeight || r.bottom < 0) continue;
      const ratio = r.width / r.height;
      if (ratio < 1.1 || ratio > 2.6) continue;
      // El más interno gana: los contenedores de la página envuelven al reproductor y
      // tienen una forma parecida, así que la profundidad distingue mejor que el aspecto.
      // Entre dos igual de internos, el que más se acerque a 16:9.
      const shape = 1 - Math.min(Math.abs(ratio - 16 / 9) / (16 / 9), 1);
      const score = depthOf(el) + shape;
      if (score <= bestScore) continue;
      best = el;
      bestScore = score;
    }
    return best;
  }

  function depthOf(el) {
    let n = 0;
    for (let p = el.parentElement; p; p = p.parentElement) n++;
    return n;
  }

  let askedAt = 0;
  async function checkOrphan() {
    // El reproductor suele ir en un <iframe> (vkvideo y otros): ahí también hace falta el
    // botón. Solo se descartan los marcos pequeños, que son anuncios y balizas.
    if (window !== window.top && (innerWidth < 320 || innerHeight < 180)) return;
    if (deepVideos().length) return dropOrphan();
    // scan() se dispara con cada cambio del DOM: no conviene preguntar tan seguido
    if (buttons.has(ORPHAN)) {
      orphanBox = findPlayerBox() || orphanBox;
      if (hasPlayerFrame(orphanBox)) return dropOrphan();
      return place();
    }
    if (Date.now() - askedAt < 2000) return;
    askedAt = Date.now();
    const res = await new Promise((done) =>
      chrome.runtime.sendMessage({ type: 'airsend:hasmedia' }, (r) => done(chrome.runtime.lastError ? null : r)));
    if (!res?.has) return dropOrphan();
    const box = findPlayerBox();
    // El reproductor va en un <iframe> (Filemoon y otros): ese marco ya pone su propio botón
    if (!box || hasPlayerFrame(box)) return dropOrphan();
    orphanBox = box;
    if (!buttons.has(ORPHAN)) addButton(ORPHAN);
    if (!host.isConnected) document.documentElement.append(host);
    place();
  }

  // ¿Ocupa el hueco del reproductor un <iframe> web grande? Ahí también corre AirSend
  // (all_frames), así que el botón lo pone ese marco y aquí saldría repetido.
  function hasPlayerFrame(box) {
    if (!box) return false;
    const b = box.getBoundingClientRect();
    return [...document.querySelectorAll('iframe')].some((f) => {
      if (!/^https?:/i.test(f.src)) return false;
      const r = f.getBoundingClientRect();
      if (r.width < 320 || r.height < 180) return false;
      const w = Math.min(r.right, b.right) - Math.max(r.left, b.left);
      const h = Math.min(r.bottom, b.bottom) - Math.max(r.top, b.top);
      return w > 0 && h > 0 && w * h >= 0.5 * r.width * r.height;
    });
  }

  function dropOrphan() {
    const btn = buttons.get(ORPHAN);
    if (btn) { btn.remove(); buttons.delete(ORPHAN); }
    orphanBox = null;
  }

  /** Vuelve a colgar el overlay solo si la página lo dejó fuera del documento.
   *  Ojo: mover el elemento reinicia su árbol y cancela el clic que se esté haciendo,
   *  así que nunca se toca mientras siga conectado. */
  function ensureHost() {
    if (host.isConnected) return;
    (document.fullscreenElement || document.documentElement).append(host);
  }

  function toast(text) {
    ensureHost();
    root.querySelector('.toast')?.remove();
    const t = document.createElement('div');
    t.className = 'toast';
    t.textContent = text;
    root.append(t);
    setTimeout(() => t.remove(), 4000);
  }

  const NO_LINK = 'No encontré el enlace de este vídeo. Dale a reproducir unos segundos y vuelve a pulsar «Enviar».';

  // Subtítulos del propio reproductor (<track>), en el formato de la app: {url, label, lang}
  function subtitles(video) {
    return [...(video?.querySelectorAll('track') || [])]
      .filter((t) => /^(subtitles|captions)$/i.test(t.kind || 'subtitles') && /^https?:/i.test(t.src))
      .slice(0, 8)
      .map((t, i) => ({ url: t.src, label: t.label || (t.srclang || '').toUpperCase() || `Subtítulos ${i + 1}`, lang: t.srclang || '' }));
  }

  // El botón huérfano no tiene <video>: se pide sin «src» y background.js usa el enlace
  // que ya detectó por red (pickMedia). El resto de datos salen de las metaetiquetas.
  const isOrphan = (v) => v === ORPHAN;

  // Con el botón huérfano no hay elemento que parar: se para lo que haya reproduciéndose
  function pauseIt(video) {
    if (!isOrphan(video)) return video.pause();
    for (const v of deepVideos()) v.pause();
  }

  function resolve(video) {
    if (isOrphan(video)) return new Promise((done) => {
      chrome.runtime.sendMessage({ type: 'airsend:resolve', src: '', page: location.href }, (res) => {
        if (chrome.runtime.lastError) return done(null);
        done(res?.media ? {
          ...res.media,
          time: 0,
          poster: document.querySelector('meta[property="og:image"]')?.content || '',
          title: document.querySelector('meta[property="og:title"]')?.content || document.title,
          tracks: [],
          page: location.href
        } : null);
      });
    });
    return new Promise((done) => {
      chrome.runtime.sendMessage({ type: 'airsend:resolve', src: video.currentSrc || video.src, page: location.href }, (res) => {
        if (chrome.runtime.lastError) return done(null);
        done(res?.media ? {
          ...res.media,
          time: Math.floor(video.currentTime || 0),
          poster: video.poster || document.querySelector('meta[property="og:image"]')?.content || '',
          title: document.querySelector('meta[property="og:title"]')?.content || document.title,
          tracks: subtitles(video),
          page: location.href
        } : null);
      });
    });
  }

  // Respuestas de page-cast.js (mundo de la página)
  let onStatus = null;
  document.addEventListener('airsend:status', (e) => onStatus?.(JSON.parse(e.detail)));
  const waitStatus = () => new Promise((done) => { onStatus = (s) => { onStatus = null; done(s); }; });

  const IS_YOUTUBE = /(^|\.)youtube(-nocookie)?\.com$/.test(location.hostname);
  const NATIVE_CAST = [
    '.ytp-remote-button', 'google-cast-launcher', '.vjs-chromecast-button', '.jw-icon-cast', '.plyr__control--cast',
    '[aria-label*="chromecast" i]', '[aria-label*="cast" i]', '[aria-label*="transmitir" i]', '[aria-label*="enviar a" i]', '[title*="chromecast" i]'
  ].join(',');

  // Botón de transmitir del propio reproductor (YouTube y otros), buscado cerca del vídeo
  function nativeCastButton(video) {
    if (IS_YOUTUBE) return document.querySelector('.ytp-remote-button');
    if (video === ORPHAN) return document.querySelector(NATIVE_CAST);
    for (let el = video.parentElement, i = 0; el && i < 6; el = el.parentElement, i++) {
      const btn = el.querySelector(NATIVE_CAST);
      if (btn) return btn;
    }
    return null;
  }

  function useNative(btn) {
    btn.click();
    toast('Elige tu tele en la lista (se usa el botón de transmitir del propio reproductor).');
  }

  const TV_SVG = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/></svg>';
  const SPK_SVG = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="2" width="14" height="20" rx="2"/><circle cx="12" cy="14" r="3.5"/><path d="M12 6h.01"/></svg>';

  const PC_DOWNLOAD = 'https://github.com/alvarosiles/AirSend/releases/download/pc-latest/AirSend-PC.zip';
  const PHONE_SVG ='<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="6" y="2" width="12" height="20" rx="2"/><path d="M11 18h2"/></svg>';

  function closePanel() { root.querySelector('.back')?.remove(); }
  addEventListener('keydown', (e) => { if (e.key === 'Escape') closePanel(); }, true);

  // Panel propio con los dispositivos de la red. Los nombres los encuentra el programa
  // de AirSend del PC (mDNS): Chrome no se los da a las extensiones.
  function openPanel(video) {
    closePanel();
    // La página puede haber reemplazado su árbol (ok.ru y otras SPA lo hacen) y dejar fuera
    // el anfitrión del Shadow DOM: el panel se añadiría a un árbol suelto y no se vería.
    ensureHost();
    const back = document.createElement('div');
    back.className = 'back';
    back.innerHTML = `<div class="panel">
      <div class="head"><b>Enviar a un dispositivo</b><button class="x" title="Cerrar">&times;</button></div>
      <div class="devs"></div>
      <div class="spin">Buscando dispositivos…</div>
      <p class="note" hidden></p>
      <button class="alt" hidden>Usar la lista de Chrome</button>
    </div>`;
    const panel = back.querySelector('.panel');
    const devs = back.querySelector('.devs');
    const spin = back.querySelector('.spin');
    const note = back.querySelector('.note');
    const alt = back.querySelector('.alt');

    back.addEventListener('click', (e) => { if (e.target === back) closePanel(); });
    panel.addEventListener('click', (e) => e.stopPropagation());
    back.querySelector('.x').onclick = closePanel;
    alt.onclick = () => { closePanel(); castWithChrome(video); };
    root.append(back);

    const say = (text, bad) => { note.hidden = false; note.textContent = text; note.className = `note${bad ? ' bad' : ''}`; };

    chrome.runtime.sendMessage({ type: 'airsend:devices' }, (res) => {
      spin.remove();
      alt.hidden = false;
      if (chrome.runtime.lastError || res?.error === 'nopc' || res?.error === 'oldpc') {
        const old = res?.error === 'oldpc';
        say(old
          ? 'Tu programa de AirSend para PC es antiguo y no sabe buscar dispositivos. Descarga el nuevo e instálalo encima.'
          : 'Para ver aquí tus dispositivos hace falta el programa de AirSend para PC.');
        const dl = document.createElement('a');
        dl.className = 'alt dl';
        dl.href = PC_DOWNLOAD;
        dl.target = '_blank';
        dl.rel = 'noopener noreferrer';
        dl.textContent = old ? 'Actualizar el programa del PC' : 'Descargar el programa del PC';
        alt.before(dl);
        alt.classList.add('ghost');
        return;
      }
      const list = res?.devices || [];
      if (!list.length) return say('No se ve ningún dispositivo en la Wi‑Fi. Comprueba que está encendido y en la misma red.');
      devs.replaceChildren(...list.map((d) => {
        const b = document.createElement('button');
        b.className = 'dev';
        const mm = d.source === 'mymultimedia';
        const spk = !mm && /home|mini|audio|speaker|nest/i.test(`${d.model} ${d.name}`) && !/tv|chromecast|display/i.test(d.model);
        b.innerHTML = `${mm ? PHONE_SVG : spk ? SPK_SVG : TV_SVG}<span><b></b><small></small></span>`;
        b.querySelector('b').textContent = d.name;
        b.querySelector('small').textContent = d.model || 'Chromecast';
        b.onclick = () => sendDirect(video, d, back);
        return b;
      }));
      say('Toca uno para enviarle este vídeo.');
      if (list.some((d) => d.proxy)) {
        const q = document.createElement('button');
        q.className = 'alt ghost';
        q.textContent = 'Añadir a la cola de la tele';
        q.onclick = () => enqueue(video);
        alt.before(q);
      }
    });
  }

  // Envía sin ninguna ventana de Chrome: el programa del PC habla directo con el receptor,
  // igual que hace la app del móvil.
  async function sendDirect(video, d, back) {
    const panel = back.querySelector('.panel');
    panel.innerHTML = `<div class="head"><b>Enviando a ${''}</b></div><div class="spin">Preparando el vídeo…</div>`;
    panel.querySelector('b').textContent = `Enviando a ${d.name}`;
    const spin = panel.querySelector('.spin');

    const media = await resolve(video);
    if (!media) { closePanel(); return toast(NO_LINK); }
    spin.textContent = 'Conectando con el receptor…';

    chrome.runtime.sendMessage({ type: 'airsend:send', id: d.id, media, page: location.href }, (res) => {
      closePanel();
      if (chrome.runtime.lastError || !res) return toast('No se pudo enviar.');
      if (res.error) return toast(res.error);
      pauseIt(video);
      toast(res.text || `Reproduciendo en ${res.device}`);
    });
  }

  // Cola de la tele: al enviarle después un vídeo a una tele que sigue sola (AirRecied para LG),
  // se le pasa la cola entera y el PC se puede apagar. Como en la app.
  async function enqueue(video) {
    closePanel();
    const media = await resolve(video);
    if (!media) return toast(NO_LINK);
    chrome.runtime.sendMessage({ type: 'airsend:enqueue', media, page: location.href }, (res) => {
      if (chrome.runtime.lastError || !res) return toast('No se pudo añadir a la cola.');
      toast(res.already ? `Este vídeo ya está en la cola (${res.count}).` : `Añadido a la cola de la tele (${res.count}). Se le pasará al enviarle un vídeo.`);
    });
  }

  async function cast(video) {
    const native = nativeCastButton(video);
    // YouTube no usa enlaces normales: su botón le dice a la tele que abra YouTube con este vídeo
    if (IS_YOUTUBE) return native ? useNative(native) : toast('En YouTube usa el botón de transmitir del reproductor.');
    openPanel(video);
  }

  async function castWithChrome(video) {
    const native = nativeCastButton(video);

    // 1.º El envío propio de Chrome (Remote Playback): su misma lista de dispositivos, y es el navegador
    // quien pasa el vídeo a la tele, así que funciona aunque la web bloquee al Chromecast y a los proxys
    if (await remotePlayback(video)) return;

    // Chrome deja abrir la lista de dispositivos hasta unos segundos después del clic
    const data = await resolve(video);
    if (!data) return native ? useNative(native) : toast(NO_LINK);

    const session = waitStatus();
    document.dispatchEvent(new CustomEvent('airsend:session'));
    const s = await session;

    if (s.state === 'cancel') return;
    if (s.state === 'nosdk') {
      if (native) return useNative(native);
      chrome.runtime.sendMessage({ type: 'airsend:open', data });
      pauseIt(video);
      return toast('Esta web no deja usar el Chromecast aquí: lo abro en la página de AirSend…');
    }
    if (s.state !== 'session') return toast('No se pudo conectar con la tele.');
    toast(`Enviando a ${s.device}…`);
    // Como en la app: directo; si la web no deja, por la nube; si también la rechaza, por este PC
    let r = await load(data);
    if (r.state !== 'playing' && data.proxied) {
      toast('La web no deja al Chromecast leer el vídeo. Probando por el proxy en la nube…');
      r = await load({ ...data, url: data.proxied });
    }
    if (r.state !== 'playing' && data.local) {
      toast('Probando a través de este PC…');
      r = await load({ ...data, url: data.local });
    }
    if (r.state === 'playing') {
      pauseIt(video);
      toast(data.local && r.url === data.local
        ? `Reproduciendo en ${r.device} a través de este PC (déjalo encendido).`
        : `Reproduciendo en ${r.device}`);
    } else if (!data.local) {
      toast('Esta web no deja enviar el vídeo directo. Instala el programa de AirSend para PC (botón «Descargar para Windows» en la ventana de AirSend) y vuelve a probar.');
    } else {
      toast('El Chromecast no pudo abrir este vídeo, ni siquiera a través de este PC.');
    }
  }

  // true si ya se ocupó (enviado o cancelado por el usuario); false si hay que probar con el SDK de Cast
  async function remotePlayback(video) {
    if (video === ORPHAN) return false;
    if (!video.remote || video.disableRemotePlayback) return false;
    try {
      await video.remote.prompt();
    } catch (e) {
      if (e.name === 'NotAllowedError') return true; // cerró la lista sin elegir
      return false; // la web o el vídeo no lo admiten
    }
    if (video.remote.state === 'disconnected') return true; // eligió "Dejar de enviar"
    toast('Conectando con la tele…');
    const connected = video.remote.state === 'connected' || await new Promise((done) => {
      const t = setTimeout(() => done(false), 20000);
      video.remote.addEventListener('connect', () => { clearTimeout(t); done(true); }, { once: true });
      video.remote.addEventListener('disconnect', () => { clearTimeout(t); done(false); }, { once: true });
    });
    if (!connected) {
      toast('No se pudo conectar con la tele.');
      return true;
    }
    video.play().catch(() => {});
    toast('Reproduciendo en la tele. Deja esta pestaña abierta mientras lo ves.');
    return true;
  }

  function load(data) {
    const done = waitStatus();
    document.dispatchEvent(new CustomEvent('airsend:load', { detail: JSON.stringify(data) }));
    return done;
  }

  function place() {
    if (buttons.size) ensureHost();
    // Varios <video> en el mismo sitio (anuncio + película, o dos capas del reproductor):
    // un solo botón, el del que está sonando o, si no, el más grande
    const items = [...buttons].map(([video, btn]) => ({ video, btn, r: rectOf(video) }));
    const score = ({ video, r }) => (video !== ORPHAN && video.currentTime > 0 ? 1e9 : 0) + r.width * r.height;
    items.sort((a, b) => score(b) - score(a));
    const placed = [];
    for (const { video, btn, r } of items) {
      // Umbral pequeño: muchos reproductores (ok.ru, VK) crean el <video> sin tamaño y lo
      // estiran un instante después. Si lo descartamos en la primera medida, no vuelve a salir.
      let visible = isLive(video) && r.width >= 120 && r.height >= 70 && r.bottom > 0 && r.top < innerHeight;
      const top = Math.max(r.top, 0) + 10;
      const right = r.right - 10;
      if (visible && placed.some((p) => Math.abs(p.top - top) < 50 && Math.abs(p.right - right) < 80)) visible = false;
      btn.style.display = visible ? 'flex' : 'none';
      if (!visible) continue;
      placed.push({ top, right });
      btn.style.top = `${top}px`;
      btn.style.left = `${right - btn.offsetWidth}px`;
    }
  }

  // El botón huérfano se coloca sobre el hueco del reproductor, no sobre un <video>
  const rectOf = (v) => (v === ORPHAN ? orphanRect() : v.getBoundingClientRect());
  const isLive = (v) => (v === ORPHAN ? orphanAlive() : v.isConnected);

  function addButton(video) {
    const btn = document.createElement('button');
    btn.className = 'btn';
    btn.title = 'Enviar a la tele con AirSend';
    btn.innerHTML = `${CAST_SVG}<span>Enviar</span>`;
    btn.addEventListener('click', (e) => { e.stopPropagation(); e.preventDefault(); cast(video); });
    root.append(btn);
    buttons.set(video, btn);
    return btn;
  }

  function scan() {
    const found = deepVideos();
    for (const video of found) if (!buttons.has(video)) addButton(video);
    for (const [video, btn] of buttons) {
      if (!isLive(video)) { btn.remove(); buttons.delete(video); }
    }
    if (found.length) dropOrphan(); else checkOrphan();
    if (buttons.size && !host.isConnected) {
      document.documentElement.append(host);
      // Carga el SDK de Cast antes del clic, para que la lista de dispositivos salga al instante
      document.dispatchEvent(new CustomEvent('airsend:prepare'));
    }
    if (buttons.size && reported !== location.href) {
      reported = location.href;
      chrome.runtime.sendMessage({ type: 'airsend:frame', url: location.href, title: document.title });
    }
    place();
  }

  // Abre una de las dos listas de dispositivos, a petición de la ventana de AirSend
  if (window === window.top) chrome.runtime.onMessage.addListener((msg, _s, reply) => {
    if (msg?.type !== 'airsend:list') return;
    const video = [...buttons.keys()].find((v) => v.isConnected) || document.querySelector('video');
    if (!video) { reply({ error: 'No hay ningún vídeo en esta pestaña.' }); return; }
    if (msg.via === 'remote') {
      if (!video.remote || video.disableRemotePlayback) { reply({ error: 'Esta web no deja usar la lista de Chrome en su vídeo. Prueba la de Chromecast.' }); return; }
      video.remote.prompt().then(() => reply({ ok: true }), (e) =>
        reply(e.name === 'NotAllowedError' ? { ok: true } : { error: 'Chrome no abrió la lista en este vídeo. Prueba la de Chromecast.' }));
      return true;
    }
    document.dispatchEvent(new CustomEvent('airsend:prepare'));
    const session = waitStatus();
    document.dispatchEvent(new CustomEvent('airsend:session'));
    session.then((s) => reply(s.state === 'nosdk'
      ? { error: 'Esta web no deja cargar el Chromecast aquí. Prueba la lista de Chrome.' }
      : { ok: true }));
    return true;
  });

  // Envíos desde el clic derecho (los hace background.js): todos los marcos reciben el aviso,
  // porque el vídeo suele estar en un reproductor incrustado y el mensaje se muestra arriba
  const playing = () => deepVideos().find((v) => v.currentTime > 0);
  // Puntero visible en la tele mientras se duplica la pestaña: la captura de Chrome no incluye
  // el ratón, así que se dibuja uno dentro de la página. En el PC queda tapado por el real.
  let pointer = null;
  const movePointer = (e) => { pointer.style.transform = `translate(${e.clientX}px, ${e.clientY}px)`; };
  function showPointer(on) {
    if (on && !pointer) {
      pointer = document.createElement('div');
      pointer.style.cssText = 'position:fixed;left:0;top:0;width:22px;height:22px;pointer-events:none;will-change:transform;transform:translate(-100px,-100px)';
      pointer.innerHTML = '<svg width="22" height="22" viewBox="0 0 24 24"><path d="M4 2l15 11.5-6.6.9 3.9 7.3-3 1.6-3.9-7.4L4 21z" fill="#fff" stroke="#000" stroke-width="1.5" stroke-linejoin="round"/></svg>';
      if (!host.isConnected) document.documentElement.append(host);
      root.append(pointer);
      addEventListener('mousemove', movePointer, { passive: true, capture: true });
    } else if (!on && pointer) {
      removeEventListener('mousemove', movePointer, { capture: true });
      pointer.remove();
      pointer = null;
    }
  }

  chrome.runtime.onMessage.addListener((msg, _s, reply) => {
    if (msg?.type === 'airsend:pointer' && window === window.top) { showPointer(msg.on); reply({ ok: true }); return; }
    if (msg?.type === 'airsend:now') {
      const v = playing();
      if (!v) return;
      reply({ time: Math.floor(v.currentTime), poster: v.poster || document.querySelector('meta[property="og:image"]')?.content || '', tracks: subtitles(v) });
      return;
    }
    if (msg?.type === 'airsend:sent') for (const v of document.querySelectorAll('video')) v.pause();
    if ((msg?.type === 'airsend:toast' || msg?.type === 'airsend:sent') && window === window.top) {
      if (!host.isConnected) document.documentElement.append(host);
      toast(msg.text);
      reply({ ok: true });
    }
  });

  // En pantalla completa solo se ve el elemento a pantalla completa: el botón se mueve dentro
  document.addEventListener('fullscreenchange', () => {
    (document.fullscreenElement || document.documentElement).append(host);
    place();
  });
  addEventListener('scroll', place, { passive: true, capture: true });
  addEventListener('resize', place);
  observer.observe(document.documentElement, { childList: true, subtree: true });
  setInterval(place, 1000);
  // Los reproductores que se montan con JS tardan: se vuelve a mirar un rato por si acaso,
  // y así el botón huérfano aparece cuando el enlace del vídeo ya se ha detectado por red.
  let tries = 0;
  const slow = setInterval(() => { if (++tries > 20) clearInterval(slow); scan(); }, 1500);
  scan();
})();
