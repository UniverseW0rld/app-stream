const list = document.getElementById('list');

function fileName(url) {
  try {
    const u = new URL(url);
    return decodeURIComponent(u.pathname.split('/').pop() || u.hostname);
  } catch { return url; }
}

function host(origin) {
  try { return new URL(origin).hostname; } catch { return origin; }
}

function render(found) {
  document.getElementById('count').textContent = found.length;
  document.getElementById('empty').hidden = found.length > 0;
  const order = (f) => (f.type === 'page' ? 2 : f.type === 'player' ? 1 : 0);
  list.replaceChildren(...found.slice().reverse().sort((a, b) => order(a) - order(b)).map((f) => {
    const hls = f.type === 'application/x-mpegurl';
    const ref = f.type === 'page' || f.type === 'player';
    const li = document.createElement('li');
    li.innerHTML = `
      <div class="top"><span class="tag ${hls ? '' : 'file'}"></span><span class="name"></span></div>
      <div class="url"></div>
      <div class="from"></div>
      <div class="actions">${ref ? '<button data-page class="main">Enviar página</button>' : ''}<button data-copy>Copiar enlace</button><a class="btn" target="_blank" rel="noopener noreferrer">Abrir</a>${ref ? '' : '<button data-queue>A la cola</button><button data-test="cloud">Probar en la nube</button><button data-test="pc">Probar en el PC</button>'}</div>
      <div class="pick" hidden></div>
      <ol class="test" hidden></ol>`;
    li.querySelector('.tag').textContent = f.type === 'page' ? 'PÁGINA' : f.type === 'player' ? 'REPRODUCTOR'
      : hls ? 'HLS' : (f.type.split('/')[1] || 'VÍDEO').toUpperCase();
    if (ref) li.querySelector('.tag').classList.add('ref');
    li.querySelector('.name').textContent = ref ? (f.title || host(f.url)) : fileName(f.url);
    li.querySelector('.url').textContent = f.url;
    li.querySelector('.from').textContent = f.from ? `Referencia: ${host(f.from)}` : '';
    li.querySelector('a').href = f.url;
    const copy = li.querySelector('[data-copy]');
    copy.onclick = async () => {
      await navigator.clipboard.writeText(f.url);
      copy.textContent = 'Copiado';
      copy.classList.add('ok');
      setTimeout(() => { copy.textContent = 'Copiar enlace'; copy.classList.remove('ok'); }, 1500);
    };
    const page = li.querySelector('[data-page]');
    if (page) page.onclick = () => pickDevice(li, f);
    const enq = li.querySelector('[data-queue]');
    if (enq) enq.onclick = async () => {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      const res = await chrome.runtime.sendMessage({
        type: 'airsend:enqueue', tabId: tab?.id, page: tab?.url || f.from,
        media: { url: f.url, type: f.type, h: f.h, title: tab?.title || fileName(f.url) }
      });
      enq.textContent = res?.already ? 'Ya en la cola' : res?.ok ? 'En la cola' : 'Error';
      enq.classList.toggle('ok', Boolean(res?.ok));
      loadQueue();
    };
    for (const test of li.querySelectorAll('[data-test]')) test.onclick = async () => {
      const out = li.querySelector('.test');
      out.hidden = false;
      out.innerHTML = '<li>Probando…</li>';
      test.disabled = true;
      const res = await chrome.runtime.sendMessage({ type: 'airsend:test', media: f, page: f.from, via: test.dataset.test });
      test.disabled = false;
      if (res.error) { out.innerHTML = '<li class="bad"></li>'; out.firstChild.textContent = res.error; return; }
      out.replaceChildren(...res.steps.map((s) => {
        const item = document.createElement('li');
        item.className = s.ok ? 'good' : 'bad';
        item.textContent = `${s.ok ? '✓' : '✗'} ${s.name}: ${s.detail}`;
        return item;
      }));
    };
    return li;
  }));
}

// «Enviar página» de una entrada de la lista: salen los dispositivos con pantalla y, al
// elegir uno, la tele abre esa dirección por su cuenta (copia estática, sin tu sesión).
const isSpeaker = (d) => /home|mini|audio|speaker|nest/i.test(`${d.model} ${d.name}`) && !/tv|chromecast|display|hub/i.test(d.model || '');

async function pickDevice(li, f) {
  const pick = li.querySelector('.pick');
  const out = li.querySelector('.test');
  if (!pick.hidden) { pick.hidden = true; return; } // segundo clic: se cierra
  out.hidden = true;
  pick.hidden = false;
  pick.innerHTML = '<small>Buscando dispositivos…</small>';
  const res = await chrome.runtime.sendMessage({ type: 'airsend:devices' });
  if (res?.error) {
    pick.innerHTML = '<small></small>';
    pick.firstChild.textContent = res.error === 'oldpc' ? 'Actualiza el programa de AirSend del PC (más abajo).' : 'Abre el programa de AirSend del PC para ver tus dispositivos (más abajo).';
    return;
  }
  const devices = (res?.devices || []).filter((d) => !isSpeaker(d));
  if (!devices.length) { pick.innerHTML = '<small>No hay ninguna tele en la Wi‑Fi.</small>'; return; }
  pick.replaceChildren(...devices.map((d) => {
    const b = document.createElement('button');
    b.innerHTML = `${TV_ICON}<span></span>`;
    b.querySelector('span').textContent = d.name;
    b.onclick = async () => {
      for (const x of pick.querySelectorAll('button')) x.disabled = true;
      out.hidden = false;
      out.innerHTML = '<li></li>';
      out.firstChild.textContent = `Enviando a ${d.name}…`;
      const r = await chrome.runtime.sendMessage({ type: 'airsend:sendpage', id: d.id, url: f.url, title: f.title || '' });
      pick.hidden = true;
      out.firstChild.className = r?.ok ? 'good' : 'bad';
      out.firstChild.textContent = r?.ok ? `✓ ${r.text}` : `✗ ${r?.error || 'No se pudo enviar la página.'}`;
    };
    return b;
  }));
}

const $ = (id) => document.getElementById(id);

// Secciones plegables: salen cerradas y se recuerda cómo las dejaste (solo en este navegador)
for (const fold of document.querySelectorAll('details.fold')) {
  const key = `airsend:fold:${fold.id}`;
  try { fold.open = localStorage.getItem(key) === '1'; } catch {}
  fold.addEventListener('toggle', () => { try { localStorage.setItem(key, fold.open ? '1' : '0'); } catch {} });
}

// Los mismos accesos directos que trae la app (android/.../Library.kt, DEFAULT_SHORTCUTS)
const SITES = [
  ['Cinecalidad', 'https://www.cinecalidad.my/'],
  ['Cuevana 3', 'https://cuevana3a.pro/'],
  ['Pelisflix', 'https://pelisflix2.co/'],
  ['RePelis24', 'https://repelis24.de/'],
  ['Cliver', 'https://cliver.mom/'],
  ['VK Video', 'https://vkvideo.ru/'],
  // Con protección anti-bots: la búsqueda solo va tras abrirlas una vez en una pestaña
  ['Gnula', 'https://ver.gnula.one/'],
  ['RepelisPlus', 'https://repelisplus.forum/'],
  ['RePelis24 Shop', 'https://repelis24.shop/'],
  ['Jujutsu Kaisen Online', 'https://jujutsukaisenonline.com/']
];
$('sites').replaceChildren(...SITES.map(([name, url]) => {
  const a = document.createElement('a');
  a.className = 'site';
  a.href = url;
  a.target = '_blank';
  a.rel = 'noopener noreferrer';
  a.title = name;
  a.innerHTML = '<span><img alt="" /></span><b></b>';
  a.querySelector('img').src = chrome.runtime.getURL(`/_favicon/?pageUrl=${encodeURIComponent(url)}&size=32`);
  a.querySelector('b').textContent = name;
  return a;
}));
// Con la rueda del ratón (que va arriba/abajo) la fila de sitios se desliza de lado
$('sites').addEventListener('wheel', (e) => {
  if (Math.abs(e.deltaY) <= Math.abs(e.deltaX)) return; // el panel táctil ya va de lado
  const el = $('sites');
  const max = el.scrollWidth - el.clientWidth;
  if (max <= 0 || (e.deltaY < 0 && el.scrollLeft <= 0) || (e.deltaY > 0 && el.scrollLeft >= max)) return; // en los extremos, sigue la página
  e.preventDefault();
  el.scrollLeft += e.deltaY;
}, { passive: false });

// ---- Buscar película en los sitios sugeridos ------------------------------
// Se usa el buscador de cada web (el mismo que en su página) y se leen sus resultados.
// Lo que va tras la dirección del sitio: «?s=» en las WordPress, «explorar?s=» en Cuevana.
// Sin «parse» (VK Video carga los resultados con JavaScript) solo se ofrece el enlace.
const SEARCH = {
  'Gnula': { path: '?s=' },
  'Jujutsu Kaisen Online': { path: '?s=' },
  'Cuevana 3': { path: 'explorar?s=' },
  'Cinecalidad': { path: '?s=' },
  'VK Video': { path: '?q=', parse: false },
  'Pelisflix': { path: '?s=' },
  'Cliver': { path: 'index.php?do=search&subaction=search&story=' },
  'RePelis24': { path: '?s=' },
  'RepelisPlus': { path: '?s=' },
  'RePelis24 Shop': { path: '?s=' }
};
const FIND_MAX = 6;

const norm = (s) => (s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();

/** Enlaces de la página de resultados cuyo título contiene todas las palabras buscadas. */
function findResults(doc, baseUrl, query) {
  const words = norm(query).split(' ').filter(Boolean);
  const base = new URL(baseUrl);
  const out = new Map();
  const titles = new Set(); // la misma película enlazada dos veces (póster y título) sale una vez
  for (const a of doc.querySelectorAll('a[href]')) {
    let href;
    try { href = new URL(a.getAttribute('href'), base); } catch { continue; }
    // Fuera del sitio (anuncios), la portada o listados con parámetros: no son fichas
    if (href.host !== base.host || href.pathname.length < 2 || href.search) continue;
    const img = a.querySelector('img');
    const label = (a.getAttribute('title') || img?.getAttribute('alt') || a.textContent || '')
      .replace(/\s+/g, ' ').replace(/^(ver\s+)?(pel[ií]cula|serie|anime)\s+/i, '').trim();
    const n = norm(label);
    // Cada palabra buscada tiene que empezar una palabra del título: «man» no vale por
    // estar dentro de «Normandy», pero «jujut» sí encuentra «Jujutsu».
    const parts = n.split(' ');
    if (!n || !words.every((w) => parts.some((p) => p.startsWith(w)))) continue;
    const key = href.href.replace(/\/$/, '');
    const src = img?.getAttribute('data-src') || img?.getAttribute('data-lazy-src') || img?.getAttribute('src') || '';
    const poster = src && !src.startsWith('data:') ? new URL(src, base).href : '';
    const prev = out.get(key);
    if (prev) { if (!prev.poster && poster) prev.poster = poster; continue; }
    if (titles.has(n)) continue;
    titles.add(n);
    // «Iron Man 3 (2013)»: el año va aparte, en la línea de datos
    const year = label.match(/\((19\d\d|20\d\d)\)\s*$/)?.[1];
    out.set(key, { title: label.replace(/\s*\((19\d\d|20\d\d)\)\s*$/, '').slice(0, 80), url: href.href, poster, info: year ? { year } : null });
  }
  return [...out.values()];
}

// ---- Año, idioma y género de cada resultado (de su ficha) ----
// Cada web los pone a su manera, pero siempre cerca del título de la película: se lee solo
// ese bloque (el menú de la web lista todos los géneros y años y daría datos falsos).
const GENRES = ['acción', 'aventura', 'animación', 'anime', 'ciencia ficción', 'c. ficción', 'comedia', 'crimen',
  'documental', 'drama', 'familia', 'fantasía', 'guerra', 'bélica', 'historia', 'misterio', 'música', 'musical',
  'romance', 'suspenso', 'suspense', 'terror', 'horror', 'thriller', 'western', 'infantil', 'deporte', 'biografía', 'policial'];
// El mismo género con otro nombre se muestra siempre igual
const SAME_GENRE = { 'c. ficción': 'ciencia ficción', suspense: 'suspenso', horror: 'terror', 'bélica': 'guerra' };
const GENRE_OF = new Map(GENRES.map((g) => { const s = SAME_GENRE[g] || g; return [norm(g), s[0].toUpperCase() + s.slice(1)]; }));

function movieInfo(doc) {
  const h1 = doc.querySelector('h1');
  if (!h1) return {};
  let box = h1;
  while (box.parentElement && box.parentElement !== doc.body && box.textContent.length < 1500) box = box.parentElement;
  const text = box.textContent.replace(/\s+/g, ' ');
  const head = `${doc.querySelector('meta[property="og:title"]')?.content || ''} ${doc.title} ${h1.textContent}`;
  const now = new Date().getFullYear();
  const okYear = (y) => y && Number(y) >= 1920 && Number(y) <= now + 1 ? y : null;
  // Año: el que va entre paréntesis en el título manda; si no, el primero del bloque
  const year = okYear(head.match(/\((19\d\d|20\d\d)\)/)?.[1]) || okYear(text.match(/\b(19[2-9]\d|20[0-3]\d)\b/)?.[1]);
  const langs = [];
  if (/\blatino\b/i.test(text)) langs.push('Latino');
  if (/\bcastellano\b/i.test(text)) langs.push('Castellano');
  if (/\bsubtitulad[oa]s?\b|\bvose\b/i.test(text)) langs.push('Sub');
  const genres = [];
  for (const a of box.querySelectorAll('a[href]')) {
    const g = GENRE_OF.get(norm(a.textContent.replace(/[,|/]/g, ' ')));
    if (g && !genres.includes(g)) genres.push(g);
  }
  return { year, langs, genres: genres.slice(0, 3) };
}

const infoCache = new Map();
async function fetchInfo(url) {
  if (infoCache.has(url)) return infoCache.get(url);
  const p = fetch(url, { credentials: 'include', signal: AbortSignal.timeout(15000) })
    .then(async (r) => (r.ok ? movieInfo(new DOMParser().parseFromString(await r.text(), 'text/html')) : {}))
    .catch(() => ({}));
  infoCache.set(url, p);
  return p;
}

// Una sola cola para todas las webs, de 5 en 5, para no saturar la conexión ni a las webs
const infoQueue = [];
let infoActive = 0;
function pumpInfo() {
  while (infoActive < 5 && infoQueue.length) {
    const { res, done } = infoQueue.shift();
    infoActive++;
    fetchInfo(res.url).then((got) => {
      res.info = { ...got, year: res.info?.year || got.year };
      paintInfo(res);
    }).finally(() => { infoActive--; done(); pumpInfo(); });
  }
}
function fillInfo(groups) {
  const todo = groups.flatMap((g) => (g.results || []).slice(0, FIND_MAX));
  return Promise.all(todo.map((res) => new Promise((done) => { infoQueue.push({ res, done }); pumpInfo(); })));
}

async function searchSite(name, siteUrl, query) {
  const cfg = SEARCH[name];
  const url = siteUrl + cfg.path + encodeURIComponent(query).replace(/%20/g, '+');
  if (cfg.parse === false) return { name, siteUrl, url, results: null };
  try {
    // credentials: las cookies del navegador (algunas webs piden la de su protección anti-bots)
    const r = await fetch(url, { credentials: 'include', signal: AbortSignal.timeout(15000) });
    // 403/503 con Cloudflare: la web pide pasar su comprobación anti-bots. Se pasa abriéndola
    // una vez en una pestaña normal (el pase queda en una cookie que esta búsqueda reutiliza).
    if (r.status === 403 || r.status === 503) return { name, siteUrl, url, error: 'bloqueada: ábrela una vez' };
    if (!r.ok) return { name, siteUrl, url, error: `no responde (${r.status})` };
    const doc = new DOMParser().parseFromString(await r.text(), 'text/html');
    return { name, siteUrl, url, results: findResults(doc, r.url, query) };
  } catch {
    return { name, siteUrl, url, error: 'no responde' };
  }
}

// Resultado pintado en pantalla por su enlace, para completar sus datos al llegar
const shownItems = new Map();
function paintInfo(res) {
  const a = shownItems.get(res.url);
  if (!a) return;
  const i = res.info || {};
  // Lo que la web no trae, no se pone
  a.querySelector('.fm').textContent = [i.year, ...(i.langs || [])].filter(Boolean).join(' · ');
  a.querySelector('.fg').textContent = (i.genres || []).join(' · ');
}

function renderFind(groups) {
  shownItems.clear();
  $('findOut').replaceChildren(...groups.map((g) => {
    const box = document.createElement('div');
    box.className = 'fsite';
    box.innerHTML = '<div class="fsite-head"><img alt="" /><b></b><small></small><a target="_blank" rel="noopener noreferrer">Ver en la web</a></div>';
    box.querySelector('img').src = chrome.runtime.getURL(`/_favicon/?pageUrl=${encodeURIComponent(g.siteUrl)}&size=32`);
    box.querySelector('b').textContent = g.name;
    const state = box.querySelector('small');
    box.querySelector('a').href = g.url;
    if (g.loading) state.textContent = 'Buscando…';
    else if (g.error) state.textContent = g.error;
    else if (!g.results) state.textContent = 'ábrelo para ver los resultados';
    else if (!g.results.length) state.textContent = 'no la tiene';
    else { state.textContent = `${g.results.length} encontrada${g.results.length > 1 ? 's' : ''}`; state.className = 'on'; }
    for (const res of (g.results || []).slice(0, FIND_MAX)) {
      const a = document.createElement('a');
      a.className = 'fres';
      a.href = res.url;
      a.target = '_blank';
      a.rel = 'noopener noreferrer';
      a.title = res.url;
      a.innerHTML = `${res.poster ? '<img alt="" loading="lazy" referrerpolicy="no-referrer" />' : '<i></i>'}<div><span></span><small class="fm"></small><small class="fg"></small></div>`;
      if (res.poster) {
        const img = a.querySelector('img');
        img.src = res.poster;
        img.onerror = () => img.replaceWith(document.createElement('i'));
      }
      a.querySelector('span').textContent = res.title;
      shownItems.set(res.url, a);
      paintInfo(res);
      box.append(a);
    }
    return box;
  }));
}

async function runFind(query) {
  query = query.trim();
  if (!query) return;
  const sites = SITES.filter(([name]) => SEARCH[name]);
  const groups = sites.map(([name, url]) => ({ name, siteUrl: url, url, loading: true }));
  renderFind(groups);
  // Cada sitio se pinta en cuanto contesta: no hay que esperar al más lento
  const fills = [];
  await Promise.all(sites.map(async ([name, url], i) => {
    groups[i] = await searchSite(name, url, query);
    renderFind(groups);
    fills.push(fillInfo([groups[i]])); // año, idioma y género, según van llegando
  }));
  await Promise.all(fills);
  // Al pulsar un resultado se abre una pestaña y esta ventana se cierra: se guarda lo
  // buscado para enseñarlo otra vez al volver a abrirla (hasta cerrar el navegador)
  chrome.storage.session.set({ lastFind: { query, groups } }).catch(() => {});
}

$('find').onsubmit = (e) => { e.preventDefault(); runFind($('findQ').value); };
chrome.storage.session.get('lastFind').then(({ lastFind }) => {
  if (!lastFind || $('findQ').value) return;
  $('findQ').value = lastFind.query;
  renderFind(lastFind.groups);
}).catch(() => {});

// ---- Tus dispositivos ----------------------------------------------------
// Chrome no deja a una extensión leer los nombres de la lista que él dibuja, así
// que los nombres vienen del programa de AirSend en el PC, que busca las teles
// por la Wi‑Fi (mDNS). Al elegir una se envía con el SDK de Cast desde la pestaña.
const TV_ICON = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/></svg>';
const SPEAKER_ICON = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="2" width="14" height="20" rx="2"/><circle cx="12" cy="14" r="3.5"/><path d="M12 6h.01"/></svg>';

function tvState(n, text) {
  $('tvCount').textContent = n === null ? '?' : n;
  $('tvCount').className = n === null ? '' : n ? 'on' : 'off';
  $('tvText').textContent = text;
}

const PHONE_ICON = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="6" y="2" width="12" height="20" rx="2"/><path d="M11 18h2"/></svg>';
const isMM = (d) => d.source === 'mymultimedia';
function deviceIcon(d) {
  if (isMM(d)) return PHONE_ICON;
  const speaker = /home|mini|audio|speaker|nest/i.test(`${d.model} ${d.name}`) && !/tv|chromecast|display/i.test(d.model || '');
  return speaker ? SPEAKER_ICON : TV_ICON;
}

// Dispositivos que ve el programa del PC: también son los que se pueden elegir en el mando
let devList = [];

function renderDevices(devices) {
  devList = devices;
  rmPaintDevs();
  $('tvList').replaceChildren(...devices.map((d) => {
    const li = document.createElement('li');
    li.innerHTML = `${deviceIcon(d)}<div><b></b><small></small></div>`;
    li.querySelector('b').textContent = d.name;
    li.querySelector('small').textContent = isMM(d) ? `${d.model || 'My Multimedia'} · tócalo para controlarlo` : d.model || 'Chromecast';
    // My Multimedia no sale en la lista de Chrome: se elige para el mando
    li.onclick = () => (isMM(d) ? rmPick(d) : sendTo(d));
    return li;
  }));
}

// Elegir una tele: el SDK de Cast no deja indicar el dispositivo por código, así que
// Chrome abre su ventana para confirmar. Aquí ya sabemos cuál hay que tocar en ella.
async function sendTo(d) {
  tvState(null, `Ahora elige «${d.name}» en la ventana que abre Chrome.`);
  await openChromeList('cast');
}

async function loadDevices() {
  $('tvAgain').disabled = true;
  const res = await chrome.runtime.sendMessage({ type: 'airsend:devices' });
  $('tvAgain').disabled = false;
  $('tvAgain').hidden = false;
  if (res?.error === 'nopc') {
    renderDevices([]);
    return tvState(null, 'Para ver aquí los nombres de tus teles, instala el programa de AirSend en el PC (más abajo). Mientras tanto, usa la lista de Chrome.');
  }
  if (res?.error) { renderDevices([]); return tvState(null, res.error); }
  const devices = res?.devices || [];
  renderDevices(devices);
  tvState(devices.length, devices.length
    ? 'Estos son los que ves al pulsar «Enviar» sobre un vídeo.'
    : 'No se ve ninguna tele en la Wi‑Fi. Comprueba que está encendida, en la misma red, y que la red del PC es «privada», no «pública».');
}

async function openChromeList(via) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  try {
    const res = await chrome.tabs.sendMessage(tab.id, { type: 'airsend:list', via });
    if (res?.error) return tvState(null, res.error);
    window.close();
  } catch {
    tvState(null, 'AirSend no está activo en esta pestaña. Abre una web con vídeo y recárgala.');
  }
}

// ---- Cola de la tele (ver addToTvQueue en background.js) -------------------
function renderQueue(queue) {
  $('queueBox').hidden = !queue.length;
  $('queueCount').textContent = queue.length;
  $('queueList').replaceChildren(...queue.map((q, i) => {
    const li = document.createElement('li');
    li.innerHTML = '<small></small><span></span><button title="Quitar de la cola">&times;</button>';
    li.querySelector('small').textContent = `${i + 1}.`;
    li.querySelector('span').textContent = q.title || fileName(q.url);
    li.querySelector('span').title = q.url;
    li.querySelector('button').onclick = async () =>
      renderQueue((await chrome.runtime.sendMessage({ type: 'airsend:queue', op: 'remove', url: q.url }))?.queue || []);
    return li;
  }));
}
async function loadQueue() {
  renderQueue((await chrome.runtime.sendMessage({ type: 'airsend:queue' }))?.queue || []);
}
$('queueClear').onclick = async () =>
  renderQueue((await chrome.runtime.sendMessage({ type: 'airsend:queue', op: 'clear' }))?.queue || []);
loadQueue();

// ---- Mando «En la tele»: el último vídeo enviado (ver controlTv en background.js) ----
// Se pregunta el estado cada 2 s y, entre medias, la barra avanza sola si está sonando.
const PLAY_ICON = '<path d="M7 4.5v15a1 1 0 0 0 1.5.86l12.5-7.5a1 1 0 0 0 0-1.72L8.5 3.64A1 1 0 0 0 7 4.5Z"/>';
const PAUSE_ICON = '<rect x="6" y="4" width="4" height="16" rx="1"/><rect x="14" y="4" width="4" height="16" rx="1"/>';
const STATE_TEXT = { PLAYING: 'Reproduciendo', PAUSED: 'En pausa', BUFFERING: 'Cargando', TRANSITIONING: 'Cargando', IDLE: 'Terminado' };
// Errores del mando que son de conexión (no de la tele): con ellos no se puede hacer nada
const LINK_ERRORS = ['nopc', 'oldpc'];
const rm = { state: '', pos: 0, dur: 0, at: 0, busy: false, dragging: false, volume: null, muted: false };
const SOUND_ICON = '<path d="M11 5 6 9H2v6h4l5 4V5Z"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/><path d="M19 5a10 10 0 0 1 0 14"/>';
const MUTED_ICON = '<path d="M11 5 6 9H2v6h4l5 4V5Z"/><path d="m22 9-6 6"/><path d="m16 9 6 6"/>';
const clock = (ms) => {
  const s = Math.max(0, Math.floor(ms / 1000));
  const hh = Math.floor(s / 3600), mm = Math.floor(s / 60) % 60, ss = String(s % 60).padStart(2, '0');
  return hh ? `${hh}:${String(mm).padStart(2, '0')}:${ss}` : `${mm}:${ss}`;
};

function rmControls(on) {
  for (const id of ['rmBack', 'rmPlay', 'rmFwd', 'rmStop', 'rmQuit']) $(id).disabled = !on;
  $('rmSeek').disabled = !on || !rm.dur;
  for (const id of ['rmMute', 'rmVolDown', 'rmVolUp']) $(id).disabled = !on || rm.volume === null;
}

function rmPaintVolume() {
  $('rmVol').textContent = rm.volume === null ? '--%' : rm.muted ? 'Mudo' : `${rm.volume}%`;
  $('rmMuteIcon').innerHTML = rm.muted ? MUTED_ICON : SOUND_ICON;
}

// Idiomas del vídeo: un botón por pista de audio (solo si hay más de una)
const LANG_NAMES = (() => { try { return new Intl.DisplayNames(['es'], { type: 'language' }); } catch { return null; } })();
function audioName(a) {
  if (a.name && !/^(und|audio|track|pista|sound)?[\s_-]*\d*$/i.test(a.name)) return a.name;
  const l = (a.lang || '').toLowerCase();
  if (/^es-(419|mx|ar|co|cl|pe|us|la)/.test(l)) return 'Latino';
  if (l === 'es-es') return 'Castellano';
  try {
    const n = l && l !== 'und' && LANG_NAMES?.of(l);
    if (n && n.toLowerCase() !== l) return n[0].toUpperCase() + n.slice(1);
  } catch {}
  return l && l !== 'und' ? l.toUpperCase() : 'Audio';
}
function rmPaintAudio(list, enabled) {
  const box = $('rmAudioList');
  // Recién elegido un idioma, se respeta lo que se pulsó hasta que la tele lo confirme
  if (rm.audioPick !== undefined && Date.now() - rm.audioAt < 4000) {
    list = list.map((a) => ({ ...a, on: String(a.id) === String(rm.audioPick) }));
  }
  $('rmAudio').hidden = !(list?.length > 1);
  if ($('rmAudio').hidden) { box.replaceChildren(); rm.audioKey = ''; return; }
  const key = JSON.stringify(list) + enabled;
  if (key === rm.audioKey) return; // sin cambios: no se rehace (evita parpadeos)
  rm.audioKey = key;
  const seen = {};
  box.replaceChildren(...list.map((a) => {
    let name = audioName(a);
    seen[name] = (seen[name] || 0) + 1;
    if (seen[name] > 1) name += ` ${seen[name]}`;
    const b = document.createElement('button');
    b.textContent = name;
    b.title = `Audio en ${name}`;
    b.className = a.on ? 'on' : '';
    b.disabled = !enabled;
    b.onclick = () => {
      if (a.on) return;
      rm.audioPick = a.id; rm.audioAt = Date.now();
      rmPaintAudio(list, enabled);
      rmSend('audio', a.id);
    };
    return b;
  }));
}

function rmMsg(text) {
  $('rmMsg').hidden = !text;
  $('rmMsg').textContent = text || '';
}

// Posición estimada ahora mismo (la del último estado más lo que lleva sonando desde entonces)
const rmNow = () => (rm.state === 'PLAYING' ? Math.min(rm.dur || Infinity, rm.pos + (Date.now() - rm.at)) : rm.pos);

function rmPaint() {
  const pos = rmNow();
  if (!rm.dragging) {
    $('rmSeek').max = String(rm.dur || 0);
    $('rmSeek').value = String(pos);
    $('rmPos').textContent = clock(pos);
  }
  $('rmDur').textContent = rm.dur ? clock(rm.dur) : '--:--';
}

// Fila de dispositivos del mando: el elegido va resaltado
function rmPaintDevs() {
  const key = JSON.stringify([rm.target, devList.map((d) => d.id)]);
  if (key === rm.devsKey) return;
  rm.devsKey = key;
  $('rmDevs').hidden = !devList.length;
  $('rmDevs').replaceChildren(...devList.map((d) => {
    const b = document.createElement('button');
    b.className = d.id === rm.target ? 'on' : '';
    b.title = `Controlar ${d.name}`;
    b.innerHTML = `${deviceIcon(d)}<span></span>`;
    b.querySelector('span').textContent = d.name;
    b.onclick = () => rmPick(d);
    return b;
  }));
  // Aún no hay mando pero sí dispositivos: se enseña para poder elegir uno
  if (!rm.target && devList.length) rmRender(null);
}

async function rmPick(d) {
  if (d.id === rm.target) return;
  rm.target = d.id;
  Object.assign(rm, { state: '', pos: 0, dur: 0, volume: null, muted: false, audioKey: '' });
  rmPaintDevs();
  $('remote').hidden = false;
  $('remote').scrollIntoView({ block: 'nearest' });
  $('rmTitle').textContent = d.name;
  $('rmDevice').textContent = '';
  $('rmState').textContent = '…';
  $('rmState').className = '';
  rmControls(false);
  rmMsg(`Conectando con ${d.name}…`);
  rm.busy = true;
  try {
    rmRender(await chrome.runtime.sendMessage({ type: 'airsend:control-target', id: d.id, name: d.name }));
  } finally {
    rm.busy = false;
  }
}

function rmRender(res) {
  if (!res || res.none && !res.id) { // nada enviado ni elegido todavía
    rm.target = null;
    rmPaintDevs();
    if (!devList.length) { $('remote').hidden = true; return; }
    $('remote').hidden = false;
    rmPaintAudio([], false);
    rmControls(false);
    $('rmRetry').hidden = true;
    $('rmTitle').textContent = 'Ningún dispositivo elegido';
    $('rmDevice').textContent = '';
    $('rmState').textContent = '…';
    $('rmState').className = '';
    return rmMsg('Elige arriba qué dispositivo quieres controlar.');
  }
  $('remote').hidden = false;
  if (res.id !== rm.target) { rm.target = res.id; rmPaintDevs(); }
  // Los idiomas solo se ofrecen mientras hay vídeo en marcha (se vuelven a pintar abajo)
  if (res.error || res.none) rmPaintAudio([], false);
  $('rmTitle').textContent = res.title || 'Vídeo';
  $('rmDevice').textContent = res.name ? `en ${res.name}` : '';
  // Sin estado de la tele = no se pudo hablar con ella (el PC, la red…). Con estado, es un
  // fallo de reproducción y se trata más abajo, con la opción de seguir por el PC.
  if (res.error && (!res.state || LINK_ERRORS.includes(res.error))) {
    $('rmRetry').hidden = true;
    rmControls(false);
    $('rmQuit').disabled = false;
    $('rmState').textContent = '?';
    $('rmState').className = '';
    return rmMsg(res.error === 'nopc' ? 'Abre el programa de AirSend del PC para usar el mando.'
      : res.error === 'oldpc' ? 'Actualiza el programa de AirSend del PC (más abajo) para pausar y adelantar desde aquí.'
      : res.error);
  }
  // Recién tocado el volumen, manda lo que se ve: un estado que ya venía de camino lo pisaría
  if (typeof res.volume === 'number' && Date.now() - (rm.volAt || 0) > 2500) { rm.volume = res.volume; rm.muted = !!res.muted; }
  rmPaintVolume();
  $('rmRetry').hidden = true;
  // La tele contesta pero dice que no pudo seguir: casi siempre es la web cortando la descarga
  // (enlace caducado o que pide las cabeceras del navegador). Por el PC suele volver a ir.
  if (res.error && res.state && !LINK_ERRORS.includes(res.error)) {
    rm.state = 'IDLE';
    rmControls(false);
    $('rmQuit').disabled = false;
    $('rmState').textContent = 'Error';
    $('rmState').className = 'off';
    const why = /BAD_HTTP_STATUS|HTTP|403|404|410/i.test(res.error) ? 'la web dejó de darle el vídeo' : res.error;
    $('rmRetry').hidden = false;
    $('rmRetry').disabled = false;
    // Ya iba por el PC: puede haber sido un corte (el PC reiniciándose, la Wi-Fi…) y reenviar
    // lo arregla; si vuelve a fallar, lo más probable es que el enlace haya caducado.
    if (res.viaPc) {
      $('rmRetry').textContent = 'Reenviar desde donde iba';
      return rmMsg(`La tele no pudo seguir: ${why}. Prueba a reenviarlo; si vuelve a fallar, abre otra vez la página del vídeo y envíalo de nuevo (el enlace pudo caducar).`);
    }
    $('rmRetry').textContent = 'Seguir por el PC desde donde iba';
    return rmMsg(`La tele no pudo seguir: ${why}. Prueba a seguir a través del PC, que pide el vídeo como el navegador.`);
  }
  if (res.none) {
    rm.state = 'IDLE'; rm.pos = 0;
    rmControls(false);
    $('rmQuit').disabled = false; // sirve para quitar el mando
    $('rmState').textContent = 'Nada';
    $('rmState').className = 'off';
    rmPaint();
    return rmMsg(res.picked ? `${res.name || 'El dispositivo'} no está reproduciendo nada ahora.`
      : `${res.name || 'El dispositivo'} ya no está reproduciendo este vídeo.`);
  }
  rm.state = res.state;
  rm.pos = res.positionMs || 0;
  rm.dur = res.durationMs || rm.dur;
  rm.at = Date.now();
  rmMsg('');
  rmControls(true);
  $('rmState').textContent = STATE_TEXT[res.state] || res.state;
  $('rmState').className = res.state === 'PLAYING' ? 'on' : '';
  $('rmIcon').innerHTML = res.state === 'PLAYING' || res.state === 'BUFFERING' ? PAUSE_ICON : PLAY_ICON;
  rmPaintAudio(res.audios || [], true);
  rmPaint();
}

async function rmSend(action, value) {
  if (rm.busy && action === 'status') return; // no se pisa con una orden en marcha
  rm.busy = action !== 'status';
  try {
    rmRender(await chrome.runtime.sendMessage({ type: 'airsend:control', action, value }));
  } finally {
    if (action !== 'status') rm.busy = false;
  }
}

$('rmPlay').onclick = () => rmSend(rm.state === 'PLAYING' || rm.state === 'BUFFERING' ? 'pause' : 'play');
$('rmBack').onclick = () => rmSend('seek', Math.max(0, rmNow() - 10000));
$('rmFwd').onclick = () => rmSend('seek', rm.dur ? Math.min(rm.dur - 1000, rmNow() + 30000) : rmNow() + 30000);
$('rmStop').onclick = () => rmSend('stop');
// Reenviar el mismo vídeo por el PC, desde donde iba (la tele ya no lo podía descargar sola)
$('rmRetry').onclick = async () => {
  $('rmRetry').disabled = true;
  rmMsg('Reenviando a través del PC…');
  rm.busy = true;
  // rm.pos guarda la última posición buena vista en esta ventana; si no hay, la recuerda el fondo
  const out = await chrome.runtime.sendMessage({ type: 'airsend:control-retry', position: rm.pos });
  rm.busy = false;
  if (out?.ok) { rmMsg(''); $('rmRetry').hidden = true; rmSend('status'); }
  else { $('rmRetry').disabled = false; rmMsg(out?.error || 'No se pudo reenviar.'); }
};
// Salir: cierra el reproductor en la tele (vuelve a su inicio) y quita el mando
$('rmQuit').onclick = async () => {
  if (rm.state && rm.state !== 'IDLE') await chrome.runtime.sendMessage({ type: 'airsend:control', action: 'quit' });
  await chrome.runtime.sendMessage({ type: 'airsend:control-forget' });
  rmRender(null); // con dispositivos a la vista, el mando queda para elegir otro
};
// Volumen de 10 en 10. Se pinta al momento para poder pulsar varias veces seguidas.
const setVolume = (v) => {
  rm.volume = Math.min(100, Math.max(0, v));
  rm.muted = false;
  rm.volAt = Date.now();
  rmPaintVolume();
  rmSend('volume', rm.volume);
};
$('rmVolDown').onclick = () => setVolume((rm.volume ?? 50) - 10);
$('rmVolUp').onclick = () => setVolume((rm.volume ?? 50) + 10);
$('rmMute').onclick = () => {
  rm.muted = !rm.muted;
  rm.volAt = Date.now();
  rmPaintVolume();
  rmSend('mute', rm.muted);
};
// Barra: mientras se arrastra solo cambia el número; al soltar, la tele salta ahí
$('rmSeek').oninput = () => { rm.dragging = true; $('rmPos').textContent = clock(Number($('rmSeek').value)); };
$('rmSeek').onchange = () => { rm.dragging = false; rmSend('seek', Number($('rmSeek').value)); };

rmSend('status');
setInterval(() => rmSend('status'), 2000);
setInterval(() => { if (rm.state === 'PLAYING') rmPaint(); }, 250);

$('tvRemote').onclick = () => openChromeList('remote');
$('tvAgain').onclick = loadDevices;
loadDevices();

function proxyMsg(text, kind = '') {
  $('proxyMsg').textContent = text;
  $('proxyMsg').className = `hint ${kind}`;
}
function proxyState(on) {
  $('proxyState').textContent = on ? 'Activado' : 'Sin configurar';
  $('proxyState').className = on ? 'on' : '';
}

chrome.storage.local.get(['proxyUrl', 'proxyKey'], ({ proxyUrl = '', proxyKey = '' }) => {
  $('proxyUrl').value = proxyUrl;
  $('proxyKey').value = proxyKey;
  proxyState(Boolean(proxyUrl && proxyKey));
});

// Tres casos: no instalado, instalado pero viejo, o al día. El segundo es el importante:
// sin avisar, el programa antiguo sigue corriendo y los dispositivos no aparecen.
chrome.runtime.sendMessage({ type: 'airsend:pcstatus' }, (res) => {
  const on = Boolean(res?.url);
  const old = Boolean(res?.outdated);
  $('pcState').textContent = !on ? 'Apagado' : old ? 'Desactualizado' : 'Activo';
  $('pcState').className = !on ? '' : old ? 'warn' : 'on';
  // GitHub todavía no publicó la versión que pide la extensión (se está generando)
  const pending = old && (res.published || 0) < res.latest;
  $('pcText').textContent = !on
    ? 'Necesario para ver tus dispositivos y enviarles el vídeo. Se instala una vez y funciona en segundo plano.'
    : old
      ? `Tienes la versión ${res.version || '?'} y esta extensión necesita la ${res.latest}. Descárgala e instálala encima para que todo funcione bien.`
        + (pending ? ' (Si la descarga aún es la anterior, espera unos minutos: se está publicando.)' : '')
      : `Versión ${res.version} (la última) · buscando dispositivos en tu Wi‑Fi · ${new URL(res.url).host}`;
  $('pcInstall').hidden = on && !old;
  $('dlText').textContent = old ? `Actualizar a la versión ${res.latest}` : 'Descargar para Windows';
  $('pcSteps').hidden = false;
  if (old) $('stepLast').textContent = `Vuelve a abrir esta ventana: debe decir «Activo» y «Versión ${res.latest}».`;
});

$('proxySave').onclick =async () => {
  const proxyUrl = $('proxyUrl').value.trim().replace(/\/+$/, '');
  const proxyKey = $('proxyKey').value.trim();
  if (!/^https:\/\//i.test(proxyUrl) || !proxyKey) return proxyMsg('Escribe la dirección (https://…) y la clave.', 'err');
  proxyMsg('Probando…');
  const res = await chrome.runtime.sendMessage({ type: 'airsend:ping', proxyUrl, proxyKey });
  if (!res?.ok) return proxyMsg(res?.text || 'No responde.', 'err');
  await chrome.storage.local.set({ proxyUrl, proxyKey });
  proxyState(true);
  proxyMsg('Proxy en la nube conectado.', 'ok');
};

$('proxyGen').onclick = () => {
  if ($('proxyKey').value && !confirm('Ya hay una clave. Si generas otra, tendrás que cambiarla también en Cloudflare y en la app. ¿Seguir?')) return;
  const bytes = crypto.getRandomValues(new Uint8Array(24));
  $('proxyKey').value = btoa(String.fromCharCode(...bytes)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  $('proxyKey').type = 'text';
  proxyMsg('Clave nueva generada. Cópiala y ponla en Cloudflare como CASTPLAY_KEY.', 'ok');
};

$('proxyCopy').onclick = async () => {
  if (!$('proxyKey').value) return proxyMsg('No hay clave que copiar.', 'err');
  await navigator.clipboard.writeText($('proxyKey').value);
  proxyMsg('Clave copiada.', 'ok');
};

$('proxyClear').onclick =async () => {
  await chrome.storage.local.remove(['proxyUrl', 'proxyKey']);
  $('proxyUrl').value = $('proxyKey').value = '';
  proxyState(false);
  proxyMsg('');
};

chrome.tabs.query({ active: true, currentWindow: true }, async ([tab]) => {
  const key = `tab:${tab?.id}`;
  render((await chrome.storage.session.get(key))[key] || []);
  chrome.storage.session.onChanged.addListener((changes) => {
    if (changes[key]) render(changes[key].newValue || []);
  });
});
